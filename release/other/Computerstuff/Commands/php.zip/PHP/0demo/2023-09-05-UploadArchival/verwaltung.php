<?php
/*
 * Download-Archiv - Verwaltung (verwaltung.php)
 * - https://werner-zenk.de
 */


session_start();
include __DIR__ . "/konfiguration.php";

// Benutzer (Admin.) überprüfen
if (!isset($_SESSION["benutzername"]) ||
    $_SESSION["benutzername"] != $ADMINISTRATOR) {

 // Zur Anmeldung weiterleiten
 header("Location: anmeldung.php");
 exit;
}


$output = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

 // Hochladen
 if (isset($_POST["hochladen"])) {

  if (is_uploaded_file($_FILES["file"]["tmp_name"])) {
   if (!file_exists($archiv . $_FILES["file"]["name"])) {
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $archiv . $_FILES["file"]["name"])) {

     $output = '<p class="ok code">&#10004; Die Datei:  &bdquo;' . $_FILES["file"]["name"] . '&rdquo; wurde hochgeladen.</p>';

     $insert = $db->prepare("INSERT INTO `download-archiv`
                                           (`name`, `description`, `size`, `hits`, `date`)
                                           VALUES (:name, :description, :size, 0, :date)");

     if ($insert->execute( [':name' => $_FILES["file"]["name"],
                                       ':description' => $_POST["description"],
                                       ':size' => $_FILES["file"]["size"],
                                       ':date' => date("d.m.Y") ])) {
      $output .= '<p class="status code">&#10004; Die Daten wurden aktualisiert.</p>';
     }
    }
   }
   else {
    $output = '<p class="ko code">&#10006; Die Datei:  &bdquo;' . $_FILES["file"]["name"] . '&rdquo; ist bereits vorhanden!</p>';
   }
  }
 }

 // Löschen
 if (isset($_POST["files"])) {

  $params = $_POST["files"];
  $placeholder = implode(',', array_fill(0, count($params), '?'));

  // Datei löschen
  $select = $db->prepare("SELECT `name` FROM `download-archiv` WHERE `id` IN (" . $placeholder . ")");
  $select->execute($params);
  $filelist = $select->fetchAll();

  foreach ($filelist as $file) {
   if (file_exists($archiv . $file["name"])) {
    if (unlink($archiv . $file["name"])) {
     $output .= '<p class="ok code">&#10004; Die Datei: &bdquo;' . $file["name"] . '&rdquo; wurde gelöscht.</p>';
    }
   }
  }

  // Eintrag löschen
  $delete = $db->prepare("DELETE FROM `download-archiv` WHERE `id` IN (" . $placeholder . ")");
  if ($delete->execute($params)) {
   $output .= '<p class="status code">&#10004; Die Daten wurden aktualisiert.</p>';
  }
 }

 // Beschreibung ändern
 if (isset($_POST["option"]) &&
  $_POST["option"] != "off" && 
  $_POST["description_edit"] != "") {

  $update = $db->prepare("UPDATE `download-archiv`
                                        SET
                                         `description` = :description_edit
                                          WHERE `id` = :id");

  if ($update->execute([':description_edit' => $_POST["description_edit"],
                                    ':id' => $_POST["option"] ])) {
   $output .= '<p class="status code">&#10004; Die Daten wurden aktualisiert.</p>';
  }
 }
}

// Ausgabe
$output .= '
<table id="tabelle" class="sortierbar">
<thead>
 <tr>
  <th class="sortierbar mark">#</th>
  <th class="sortierbar">Dateiname</th>
  <th class="sortierbar">Beschreibung</th>
  <th class="sortierbar">Größe</th>
  <th class="sortierbar">Hits</th>
  <th class="sortierbar">Datum</th>
 </tr>
</thead>
<tbody>';

$select = $db->query("SELECT `id`, `name`, `description`, `size`, `hits`, `date` FROM `download-archiv`");
$filelist = $select->fetchAll();

$unique = date("dYm");
foreach ($filelist as $nr => $file) {
 $output .= '<tr><td class="nummer mark" title="Nummer ' . ($nr+1) . '">' . ($nr+1) .
  ' <input type="checkbox" name="files[]" value="' . $file["id"] . '" id="lbl' . $nr . '"></td>' .
  '<td class="langertext">' .
  '<a href="herunterladen.php?id=' . base64_encode($unique . '|' . $file["id"]) . '" class="speichern" title="Die Datei: &#8220;' . $file["name"] . '&#8220; herunterladen&#10;oder die Link-Adresse kopieren."></a> ' .
  '<label for="lbl' . $nr . '">' . $file["name"] . '</label></td>' .
  '<td class="langertext" title="Beschreibung"><label><input type="radio" name="option" value="' . $file["id"] . '" onClick="descriptionEdit(`' . htmlspecialchars($file["description"], ENT_HTML5) . '`)" title="Beschreibung ändern"> ' . $file["description"] . '</label></td>' .
  '<td class="nummer" title="Dateigröße">' . size($file["size"]) . '</td>' .
  '<td class="hits" title="Hits">' . $file["hits"] . '</td>' .
  '<td title="Datum">' . $file["date"] . '</td></tr>';
}

$output .= '
</tbody>
<tfoot>
 <tr>
  <th colspan="2">
   <label><input onclick="check_all(`files[]`, this)" type="checkbox"> Markieren</label>&nbsp;
   <button type="submit">Markierte löschen</button>
  </th>
  <th colspan="5" class="mark">
    <label title="Keine Beschreibung ändern"><input type="radio" name="option" value="off" checked="checked" onClick="descriptionEdit(``)"></label>
   <label>Beschreibung: <input type="text" name="description_edit" id="description_edit" size="20"></label>&nbsp;
   <button type="submit">ändern</button>
 </th>
 </tr>
</tfoot>
</table>';
?>
<!DOCTYPE html>
<html lang="de">
 <head>
  <meta charset="UTF-8">
  <title>Download-Archiv - Verwaltung</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <script src="tabletsort.js"></script>
  <script src="resizable.js"></script>
  <script src="javascript.js"></script>
  <link rel="stylesheet" href="style.css">
 </head>
<body>

<form method="post" enctype="multipart/form-data">
<fieldset>
 <legend>Download-Archiv - Verwaltung - <a href="anmeldung.php?abmeldung" title="Klicken Sie hier um sich abzumelden">Abmelden</a></legend>
 <p>
  <input type="file" name="file" required="required"><br>
  <small>Formate: .jpg, .png, .webp, .zip, pdf, .txt, .exe, &hellip; etc. - Max. Dateigröße: <?=ini_get("upload_max_filesize")?>B</small>
 </p>
 <p>
  <label>Beschreibung:
  <input type="text" name="description" id="description" size="33" spellcheck="true"></label><br>
  <small>Eine kurze und prägnante Beschreibung der Datei.</small>
 </p>
 <p>
  <input type="submit" name="hochladen" value="Datei hochladen">
 </p>
</fieldset>
</form>

<form method="post" onSubmit="return sicherheit();">
<?=$output;?>
</form>

</body>
</html>