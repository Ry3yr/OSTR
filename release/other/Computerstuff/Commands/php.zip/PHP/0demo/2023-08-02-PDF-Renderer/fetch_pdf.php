<?php
// Get the URL parameter
$url = $_GET['url'];

// Initialize cURL
$curl = curl_init();

// Set cURL options
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HEADER, false);

// Execute the cURL request
$response = curl_exec($curl);

// Check for errors
if ($response === false) {
    die('Error fetching PDF: ' . curl_error($curl));
}

// Close cURL
curl_close($curl);

// Set the appropriate headers
header('Content-Type: application/pdf');
header('Content-Disposition: inline; filename="document.pdf"');
header('Content-Length: ' . strlen($response));

// Output the PDF content
echo $response;
?>