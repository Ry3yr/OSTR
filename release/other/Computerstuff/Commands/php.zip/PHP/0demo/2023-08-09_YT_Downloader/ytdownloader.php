<?php

// Set your API key
$API_KEY = $_POST['api_key'];

// Set the YouTube video URL
$video_url = $_POST['video_url'];

// Extract the video ID from the URL
$video_id = explode("v=", $video_url)[1];

// Construct the API request URL
$api_url = "https://www.googleapis.com/youtube/v3/videos?id={$video_id}&key={$API_KEY}&part=snippet";

try {
    // Make the API request
    $response = file_get_contents($api_url);
    $data = json_decode($response, true);

    // Get video details
    $video_title = $data['items'][0]['snippet']['title'];

    // Get the available video formats
    $video_formats = $data['items'][0]['snippet']['thumbnails']['default']['url'];

    // Get the highest quality thumbnail
    $thumbnail_url = $data['items'][0]['snippet']['thumbnails']['maxres']['url'];

    // Create the "downloads" folder if it doesn't exist
    $folder_path = __DIR__ . "/downloads";
    if (!is_dir($folder_path)) {
        mkdir($folder_path);
    }

    // Download the video
    $file_path = $folder_path . "/" . $video_title . ".mp4";
    $video_data = file_get_contents($video_formats);
    file_put_contents($file_path, $video_data);

    echo "Video downloaded successfully!";
} catch (Exception $e) {
    echo "An error occurred: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>YouTube Video Downloader</title>
</head>
<body>
    <form method="POST" action="">
        <label for="api_key">API Key:</label>
        <input type="text" id="api_key" name="api_key" required>

        <br>

        <label for="video_url">YouTube Video URL:</label>
        <input type="text" id="video_url" name="video_url" required>

        <br>

        <input type="submit" value="Download">
    </form>
</body>
</html>