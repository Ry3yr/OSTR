﻿/* Download-Archiv (javascript.js)
 * - http://werner-zenk.de
*/


window.addEventListener("DOMContentLoaded", function() {
 var elem = document.querySelectorAll(".code");
 elem.forEach(function(ele) {
  ele.title="Zum schließen klicken!";
  ele.addEventListener( 'click', function() {
  ele.style.display="none";
  });
 });

 resizableGrid(document.getElementById("tabelle"));
});

function sicherheit() {
 let cb = document.querySelectorAll('input[name="files[]"]:checked');
 if (cb.length > 0) {
  var datei = (cb.length == 1) ? 'Datei' : cb.length + ' Dateien';
  if (confirm("Möchten Sie diese " + datei + " wirklich löschen?")) {
   return true;
  }
  else {
   return false;
  }
 }
}

function dl(id) {
 document.querySelector('#laden').classList.add("laden");
 window.setTimeout(function () {
  document.querySelector('#laden').classList.remove("laden");
  window.location.href="herunterladen.php?id=" + id;
 },1300);
}

function check_all(name, el) {
 var box = el.form.elements[name];
 if (!box.length) {
  box.checked = el.checked;
 }
 else {
  for (var i = 0; i < box.length; i++) {
   box[i].checked = el.checked;
  }
 }
}

function descriptionEdit(val) {
 document.getElementById("description_edit").value = val;
}