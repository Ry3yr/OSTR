<?php
// Get the current directory
$dir = getcwd();

// Get all image files in the directory and its subdirectories
$images = glob($dir . '/**/*.{jpg,jpeg,png,gif}', GLOB_BRACE);

// Group the images by directory
$imageGroups = array();
foreach ($images as $image) {
    $dirName = dirname($image);
    $fileName = basename($image);
    if (!isset($imageGroups[$dirName])) {
        $imageGroups[$dirName] = array();
    }
    $imageGroups[$dirName][] = $fileName;
}

// Display the images grouped by directory
foreach ($imageGroups as $dirName => $images) {
    $dirName = str_replace("/home/vol17_2/byethost7.com/b7_33430930/htdocs/", "http://alceawisteria.byethost7.com/", $dirName);
    echo '<h2>' . $dirName . '</h2>';
    foreach ($images as $image) {
        echo '<img src="' . $dirName . '/' . $image . '">';
    }
}
?>