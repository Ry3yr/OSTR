<!DOCTYPE html>
<html>
<head>
	<title>Check Webpage Syntax Errors</title>
	<style>
		.error {
			color: red;
		}
	</style>
</head>
<body>
	<h1>Check Webpage Syntax Errors</h1>
	<form method="post">
		<label for="url">Enter URL:</label>
		<input type="text" id="url" name="url">
		<button type="submit">Check Syntax</button>
	</form>

	<?php
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		// Get the URL input from the user
		$url = $_POST['url'];

		// Retrieve the HTML code of the webpage
		$html = file_get_contents($url);

		// Turn off error reporting for DOMDocument
		libxml_use_internal_errors(true);

		// Create a new DOMDocument object and load the HTML code
		$dom = new DOMDocument();
		$dom->loadHTML($html);

		// Get any errors that occurred during parsing
		$errors = libxml_get_errors();

		// Display any syntax errors found
		if (!empty($errors)) {
			echo "<h2>Syntax Errors:</h2>";
			foreach ($errors as $error) {
			    if ($error->level === LIBXML_ERR_FATAL || $error->level === LIBXML_ERR_ERROR) {
			        echo "<p><span class=\"error\"><b>Syntax error on line</b> </span>" . $error->line . ": " . $error->message . "</p>";
			        $lines = explode("\n", $html);
			        $error_line = $error->line - 1;
			        echo "<p class=\"error\">" . htmlspecialchars($lines[$error_line]) . "</p>";
			    }
			}
		} else {
			echo "No syntax errors found.";
		}

		// Turn error reporting back on
		libxml_use_internal_errors(false);
	}
	?>
</body>
</html>