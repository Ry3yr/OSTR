<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $url = $_POST['url'];
    $html = file_get_contents($url);
    $datePattern = '/View albums released on ([A-Z][a-z]{2} \d{1,2}, \d{4})/';
    preg_match($datePattern, $html, $dateMatches);
    $releaseDate = $dateMatches[1];
    $reformattedDate = date('Y-m-d', strtotime($releaseDate));
    $titlePattern = '/<h1><span class="albumtitle" lang="en" style="display:inline">(.*?)<\/span>/s';
    preg_match($titlePattern, $html, $titleMatches);
    $albumTitle = $titleMatches[1];

    // Check if line is already present in file
    $fileContent = file_get_contents('pastreleases.html');
    $lineToCheck = "<p>" . $reformattedDate . " <a target=_blank href='" . $url . "'>" . $albumTitle . "</a></p>";
    if (strpos($fileContent, $lineToCheck) !== false) {
        // Line is already present, display error message
        echo "Error: Line already exists in the file.<br>";
    } else {
        // Line is not present, prepend to the file
        $fileContentToWrite = $lineToCheck . "\n" . $fileContent;
        file_put_contents('pastreleases.html', $fileContentToWrite);
    }

    echo "" . $reformattedDate . "";
    echo "<a target=_blank href='" . $url . "' target='_blank'>" . $albumTitle . "</a>";
}
?>
<head>
</head>
<body>
    <form method="POST" action="">
        <label for="url">VGMdb URL:</label>
        <input type="text" name="url" id="url" required>
        <input type="submit" value="Extract">
    </form>
</body>


<br>
<!--<a target="_blank" href="reorder.php">reorder</a>-->
<iframe src=reorder.php height=100 width=800 frameborder=0></iframe>
<br>


<iframe src="pastreleases.html?timestamp=<?php echo time(); ?>" width="600" height="400" frameborder=0></iframe>