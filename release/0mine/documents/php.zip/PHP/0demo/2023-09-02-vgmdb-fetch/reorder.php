

<!--Reorder--Function-->
<form method="POST" action="">
    <input type="submit" name="reorder" id="reorder" value="Reorder">
</form>

<?php
//ini_set('display_errors', 0);
if (isset($_POST['reorder'])) {
    // PHP Code for Reordering "pastreleases.html"
    $fileContent = file_get_contents('pastreleases.html');
    $lines = explode("\n", $fileContent);
    $lines = array_filter($lines);
    $linesWithDates = array();

    foreach ($lines as $line) {
        preg_match('/<p>(\d{4}-\d{2}-\d{2})/', $line, $dateMatches);
        if (isset($dateMatches[1]) && strtotime($dateMatches[1]) !== false) {
            $date = $dateMatches[1];
            $linesWithDates[$line] = $date;
        }
    }

    arsort($linesWithDates);
    $reorderedLines = array_keys($linesWithDates);
    $reorderedContent = implode("\n", $reorderedLines);

    // Filter lines that do not contain "https://"
    $filteredLines = array_filter($reorderedLines, function ($line) {
        return strpos($line, 'https://') !== false;
    });

    $filteredContent = implode("\n", $filteredLines);
    file_put_contents('pastreleases.html', $filteredContent);

    echo "Reordering and filtering completed successfully!";
}