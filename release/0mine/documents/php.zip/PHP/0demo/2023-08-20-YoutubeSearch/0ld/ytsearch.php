<!DOCTYPE html>
<html>
<head>
    <title>YouTube Search</title>
    <style>
        .additional-info {
            color: #888;
        }
    </style>
</head>
<body>
    <form method="GET" action="">
        <label for="api_key">API Key:</label>
        <input type="text" id="api_key" name="api_key" required><br><br>
        <label for="search_query">Search Query:</label>
        <input type="text" id="search_query" name="search_query" required><br><br>
        <label for="max_results">Max Results:</label>
        <input type="number" id="max_results" name="max_results" min="1" max="50" value="10" required><br><br>
        <input type="checkbox" id="show_additional_info" name="show_additional_info">
        <label for="show_additional_info">Show Additional Info</label><br><br>
        <button type="submit">Search</button>
    </form>
    <br><br>
    <div id="results">
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            if (isset($_GET['api_key']) && isset($_GET['search_query']) && isset($_GET['max_results'])) {
                $apiKey = $_GET['api_key'];
                $searchQuery = $_GET['search_query'];
                $maxResults = $_GET['max_results'];
                $showAdditionalInfo = isset($_GET['show_additional_info']);

                $apiUrl = 'https://www.googleapis.com/youtube/v3/search';
                $requestUrl = $apiUrl . '?part=snippet&maxResults=' . $maxResults . '&q=' . urlencode($searchQuery) . '&key=' . $apiKey;

                $response = file_get_contents($requestUrl);
                $data = json_decode($response, true);

                if (isset($data['items'])) {
                    foreach ($data['items'] as $item) {
                        if ($item['id']['kind'] === 'youtube#video') {
                            $videoId = $item['id']['videoId'];
                            $title = $item['snippet']['title'];
                            $link = 'https://www.youtube.com/watch?v=' . $videoId;

                            echo '<p>Title: ' . $title . '</p>';

                            if ($showAdditionalInfo) {
                                $channelId = $item['snippet']['channelId'];
                                $channelTitle = $item['snippet']['channelTitle'];
                                $uploadDate = $item['snippet']['publishedAt'];

                                echo '<p class="additional-info">Channel: ' . $channelTitle . ' (ID: ' . $channelId . ')</p>';
                                echo '<p class="additional-info">Upload Date: ' . $uploadDate . '</p>';
                            }

                            echo '<a href="' . $link . '" target="_blank">Link</a><br><br>';
                        }
                    }
                } else {
                    echo 'No results found.';
                }
            }
        }
        ?>
    </div>
</body>
</html>