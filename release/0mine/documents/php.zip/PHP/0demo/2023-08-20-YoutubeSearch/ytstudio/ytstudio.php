<style>
body{font-family:Arial,sans-serif;background-color:#f2f2f2}form{max-width:600px;margin:0 auto;padding:20px;background-color:#fff;border-radius:5px;box-shadow:0 2px 5px rgba(0,0,0,.1)}label{display:block;margin-bottom:10px;font-weight:bold}select,input[type="text"],button{width:100%;padding:10px;border:1px solid #ccc;border-radius:4px;box-sizing:border-box;margin-bottom:20px;font-size:14px}input[type="checkbox"],label[for="show_thumbnail"]{display:inline;margin-right:5px}button[type="submit"]{background-color:#4CAF50;color:#fff;cursor:pointer}
</style>
<!-- HTML form -->
<form method="POST" action="">
    <label for="channel_id">Channel ID:</label>
    <select id="channel_id" name="channel_id" required>
        <option value="UCrltGih11A_Nayz6hG5XtIw">Diarykeeper</option>
        <option value="UCmIpOnd5BVx5Si2hp0WNKZw">Repeekyraid_Cero</option>
    </select>
    <label for="api_key">API Key:</label>
    <input type="text" id="api_key" name="api_key" required>
    <input type="checkbox" id="show_thumbnail" name="show_thumbnail">
    <label for="show_thumbnail">Show Thumbnail</label><br>
    <button type="submit">Get Channel Videos</button>
</form>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the channel ID and API key from the form
    $channelId = $_POST['channel_id'];
    $apiKey = $_POST['api_key'];
    $url = "https://www.googleapis.com/youtube/v3/channels?part=contentDetails&id={$channelId}&key={$apiKey}";
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
    if ($response === false) {
        die('Error: cURL request failed');
    }
    $data = json_decode($response, true);
    $uploadsPlaylistId = $data['items'][0]['contentDetails']['relatedPlaylists']['uploads'];
    $playlistUrl = "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=50&playlistId={$uploadsPlaylistId}&key={$apiKey}";
    $playlistCurl = curl_init($playlistUrl);
    curl_setopt($playlistCurl, CURLOPT_RETURNTRANSFER, true);
    $playlistResponse = curl_exec($playlistCurl);
    curl_close($playlistCurl);
    if ($playlistResponse === false) {
        die('Error: cURL playlist request failed');
    }
    $playlistData = json_decode($playlistResponse, true);
    foreach ($playlistData['items'] as $item) {
        $videoId = $item['snippet']['resourceId']['videoId'];
        $videoTitle = $item['snippet']['title'];
        $videoThumbnail = $item['snippet']['thumbnails']['default']['url'];
        $videoPublishedAt = $item['snippet']['publishedAt'];
        if (isset($_POST['show_thumbnail']) && $_POST['show_thumbnail'] === 'on') {
            echo "<img src=\"$videoThumbnail\" alt=\"Thumbnail\"><br>";
        }
        echo '<a href="https://www.youtube.com/watch?v=' . $videoId . '">' . $videoTitle . '</a><br>';
        echo 'Video ID: ' . $videoId . '<br>';
        echo 'Upload Date: ' . $videoPublishedAt . '<br>';
        $commentsUrl = "https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&maxResults=5&videoId={$videoId}&key={$apiKey}";
        $commentsCurl = curl_init($commentsUrl);
        curl_setopt($commentsCurl, CURLOPT_RETURNTRANSFER, true);
        $commentsResponse = curl_exec($commentsCurl);
        curl_close($commentsCurl);
        if ($commentsResponse === false) {
            die('Error: cURL comments request failed');
        }
        $commentsData = json_decode($commentsResponse, true);
        foreach ($commentsData['items'] as $comment) {
            echo 'Comment: ' . $comment['snippet']['topLevelComment']['snippet']['textDisplay'] . '<br>';
        }
        echo '<br>';
    }
}
?>