<?php

// Set your API key here
$apiKey = 'AIzaSyAMI5iE6oUzj5qaDkwCy_YKH5qjDGFyKy4';

// Function to find YouTube comments
function findYouTubeComments($videoUrl, $keyword, $apiKey)
{
    // Extract video ID from the URL
    $videoId = getVideoIdFromUrl($videoUrl);

    // Make a request to the YouTube Data API
    $url = "https://www.googleapis.com/youtube/v3/commentThreads?part=snippet&maxResults=10&videoId={$videoId}&searchTerms={$keyword}&key={$apiKey}";
    $response = file_get_contents($url);

    // Parse the JSON response
    $data = json_decode($response, true);

    $comments = [];

    // Extract comments from the response
    if (isset($data['items'])) {
        foreach ($data['items'] as $item) {
            $commentId = $item['id'];
            $comment = $item['snippet']['topLevelComment']['snippet']['textDisplay'];
            $commentUrl = $videoUrl . '&google_comment_id=' . $commentId;
            $comments[] = array(
                'comment' => $comment,
                'commentUrl' => $commentUrl
            );
        }
    }

    return $comments;
}

// Function to extract video ID from the URL
function getVideoIdFromUrl($url)
{
    $pattern = '/(?:\?v=|\/embed\/|\/\d\/|\/vi\/|\/v\/|https?:\/\/(?:www\.)?youtube\.com\/v\/|https?:\/\/(?:www\.)?youtube\.com\/embed\/|https?:\/\/youtu\.be\/|https?:\/\/(?:www\.)?youtube\.com\/user\/[^#\/]+#p\/[^#\/]+\/|https?:\/\/(?:www\.)?youtube\.com\/s[^#\/]+\/|https?:\/\/(?:www\.)?youtube\.com\/playlist\?)([^#\&\?\/]+)/';
    preg_match($pattern, $url, $matches);
    return isset($matches[1]) ? $matches[1] : $url;
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the YouTube video URL and keyword from the form
    $videoUrl = $_POST['yturl'];
    $keyword = $_POST['keyword'];

    // Find YouTube comments based on the inputs
    $comments = findYouTubeComments($videoUrl, $keyword, $apiKey);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>YouTube Comment Finder</title>
</head>
<body>
    <h2>YouTube Comment Finder</h2>
    <form method="POST" action="">
        <label for="yturl">YouTube Video URL:</label>
        <input type="text" id="yturl" name="yturl" placeholder="Enter YouTube video URL" required><br>

        <label for="keyword">Keyword:</label>
        <input type="text" id="keyword" name="keyword" placeholder="Enter keyword" required><br>

        <button type="submit">Search</button>
    </form>

    <?php if (isset($comments)): ?>
        <h3>Comments containing the keyword:</h3>
        <?php if (empty($comments)): ?>
            <p>No comments found.</p>
        <?php else: ?>
            <ul>
                <?php foreach ($comments as $comment): ?>
                    <li>
                        <?php echo $comment['comment']; ?>
                        <br>
                        Comment URL: <a href="<?php echo $comment['commentUrl']; ?>"><?php echo $comment['commentUrl']; ?></a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>