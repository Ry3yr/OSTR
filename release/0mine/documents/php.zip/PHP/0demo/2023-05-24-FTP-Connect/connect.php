


<?php

file_put_contents(
            $filePath.$fileName, file_get_contents(
                ftp://pasc91:Flashme199!@ftp.hidrive.strato.com/users/pasc91/Clipboard.txt
            )
);    

?>



