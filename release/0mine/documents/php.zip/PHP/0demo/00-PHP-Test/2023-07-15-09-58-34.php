<?php

echo '<input type="text" name="myTextbox" id="myTextbox" value="">';

?>