<?php
$rss = simplexml_load_file('https://rsshub.app/pixiv/user/75406576');
foreach ($rss->channel->item as $item) {
    $description = (string) $item->description;
    if (preg_match('/https:\/\/\S+/', $description, $matches)) {
        $link = rtrim($matches[0], '"'); // Remove the final " character
        //echo '<p>' . htmlspecialchars($link) . '<br>';
        echo '<img src="' . htmlspecialchars($link) . '">';
    }
}
?>

<?php
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>
<a target="_blank" href="?source">Source Code</a>
</body>
</html>