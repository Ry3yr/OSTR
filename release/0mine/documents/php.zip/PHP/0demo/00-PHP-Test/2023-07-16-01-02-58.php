<?php
// Get the contents of the file
$fileContents = file_get_contents('https://ry3yr.github.io/OSTR/release/other/Computerstuff/Commands/HTML_Codes.txt');

// Define the regular expression pattern
$pattern = '/------(.*?)_____/s';

// Match the pattern in the file contents
preg_match_all($pattern, $fileContents, $matches);

// Get a random match
$randomIndex = array_rand($matches[1]);
$randomMatch = $matches[1][$randomIndex];

// Count the number of lines in the random match
$numLines = substr_count($randomMatch, "\n") + 1;

// Output the random match if it has at least 3 lines
if ($numLines >= 3) {
  echo $randomMatch;
}
?>