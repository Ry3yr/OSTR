<?php
// Get the contents of the file
$fileContents = file_get_contents('https://ry3yr.github.io/OSTR/release/other/Computerstuff/Commands/HTML_Codes.txt');

// Define the regular expression pattern
$pattern = '/------(.*?)_____/s';

// Match the pattern in the file contents
preg_match_all($pattern, $fileContents, $matches);

// Get a random match
$randomIndex = array_rand($matches[1]);
$randomMatch = $matches[1][$randomIndex];

// Output the random match
echo $randomMatch;
?>