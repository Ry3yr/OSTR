<?php
// Get the contents of both files
$htmlCodes = file_get_contents('https://ry3yr.github.io/OSTR/release/other/Computerstuff/Commands/HTML_Codes.txt');
$phpCommands = file_get_contents('https://ry3yr.github.io/OSTR/release/other/Computerstuff/Commands/PHP.txt');

// Combine the contents of the files
$combinedContents = $htmlCodes . $phpCommands;

// Define the regular expression pattern
$pattern = '/------\n(.*?\n)+_____/';

// Match the pattern in the combined contents
preg_match_all($pattern, $combinedContents, $matches);

// Get a random match
$randomIndex = array_rand($matches[0]);
$randomMatch = $matches[0][$randomIndex];

// Count the number of lines in the random match
$numLines = substr_count($randomMatch, "\n") + 1;

// Output the random match if it has at least 3 lines, wrapped in plaintext tags
if ($numLines >= 3) {
  echo '<plaintext>' . $randomMatch . '</plaintext>';
}

// Output the combined contents of both files
//echo $combinedContents;
?>