<?php
// The SoundCloud URL to extract the track ID from
$url = 'https://m.soundcloud.com/winterworks_gmbh/metal-stage';

// Fetch the SoundCloud page source
$pageSource = file_get_contents($url);

// Extract the track ID from the page source
preg_match('/sounds:(\d+)/', $pageSource, $matches);
$trackID = $matches[1];

// Embed the SoundCloud player with the track ID
$playerURL = 'https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/' . $trackID .
  '&color=%23ff5500&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true&visual=true';
$iframe = '<iframe width="100%" height="166" scrolling="no" frameborder="no" allow="autoplay" src="' . $playerURL . '"></iframe>';

// Output the embedded player
echo $iframe;
?>

<?php
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>
<a target="_blank" href="?source">Source Code</a>
</body>
</html>