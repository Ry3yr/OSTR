<!DOCTYPE html>
<html>
<head>
	<title>Message Board</title>
	<style>
		body {
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
			background-color: #f2f2f2;
		}
		h1 {
			font-size: 36px;
			text-align: center;
			margin-top: 20px;
			margin-bottom: 20px;
		}
		h2 {
			font-size: 24px;
			margin-top: 30px;
			margin-bottom: 10px;
		}
		table {
			border-collapse: collapse;
			width: 100%;
			max-width: 800px;
			margin: auto;
			background-color: white;
			box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
		}
		th, td {
			padding: 10px;
			text-align: left;
			vertical-align: top;
			border: 1px solid #ddd;
		}
		th {
			font-weight: bold;
			background-color: #f2f2f2;
		}
		tr:hover {
			background-color: #f5f5f5;
		}
		form {
			max-width: 800px;
			margin: auto;
			background-color: white;
			box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
			padding: 20px;
		}
		label {
			display: block;
			font-weight: bold;
			margin-bottom: 10px;
		}
		input[type="text"], textarea {
			display: block;
			width: 100%;
			padding: 10px;
			margin-bottom: 20px;
			border: 1px solid #ddd;
			border-radius: 5px;
			box-sizing: border-box;
			resize: vertical;
		}
		input[type="submit"] {
			background-color: #4CAF50;
			color: white;
			border: none;
			padding: 10px 20px;
			border-radius: 5px;
			cursor: pointer;
			float: right;
		}
		input[type="submit"]:hover {
			background-color: #3e8e41;
		}
	</style>
</head>
<body>
	<h1>Message Board</h1>

	<?php
	$password = 'f91'; // Change this to your desired password

	// Check if form has been submitted
	if (isset($_POST['submit'])) {
		// Get form data
		$name = $_POST['name'];
		$message = $_POST['message'];

		// Validate form data
		if (empty($name) || empty($message)) {
			echo "<p>Please fill out all fields.</p>";
		} else {
			// Save message to file
			$filename = 'messages.txt';
			$handle = fopen($filename, 'a');
			fwrite($handle, $name . '|' . $message . '|' . time() . "\n");
			fclose($handle);

			echo "<p>Message saved successfully.</p>";
		}
	}

	// Check if delete or edit form has been submitted
	if (isset($_POST['action']) && isset($_POST['id']) && $_POST['password'] === $password) {
		$action = $_POST['action'];
		$id = $_POST['id'];

		// Read messages from file
		$filename = 'messages.txt';
		if (file_exists($filename)) {
			$handle = fopen($filename, 'r');
			$messages = array();
			while (($line = fgets($handle)) !== false) {
				$parts = explode('|', $line);
				if (count($parts) == 3) {
					$messages[] = array(
						'name' => $parts[0],
						'message' => $parts[1],
						'date_added' => $parts[2]
					);
				}
			}
			fclose($handle);

			// Find message with matching ID
			$found = false;
			foreach ($messages as $key => $message) {
				if ($key == $id) {
					$found = true;
					break;
				}
			}

			if ($found) {
				// Perform requested action
				if ($action == 'delete') {
					unset($messages[$id]);
					// Re-index array keys
					$messages = array_values($messages);
					// Save messages to file
					$handle = fopen($filename, 'w');
				foreach ($messages as $message) {
						fwrite($handle, $message['name'] . '|' . $message['message'] . '|' . $message['date_added'] . "\n");
					}
					fclose($handle);
					echo "<p>Message deleted successfully.</p>";
				} else if ($action == 'edit') {
					echo "<form method=\"post\">
						<input type=\"hidden\" name=\"action\" value=\"update\">
						<input type=\"hidden\" name=\"id\" value=\"$id\">
						<label>Name:</label>
						<input type=\"text\" name=\"name\" value=\"{$messages[$id]['name']}\">
						<label>Message:</label>
						<textarea name=\"message\">{$messages[$id]['message']}</textarea>
						<label>Password:</label>
						<input type=\"password\" name=\"password\">
						<input type=\"submit\" value=\"Update\">
					</form>";
				}
			} else {
				echo "<p>Message not found.</p>";
			}
		} else {
			echo "<p>No messages found.</p>";
		}
	} else if (isset($_POST['action']) && $_POST['action'] === 'update' && isset($_POST['id']) && $_POST['password'] === $password) {
		// Get form data
		$id = $_POST['id'];
		$name = $_POST['name'];
		$message = $_POST['message'];

		// Read messages from file
		$filename = 'messages.txt';
		if (file_exists($filename)) {
			$handle = fopen($filename, 'r');
			$messages = array();
			while (($line = fgets($handle)) !== false) {
				$parts = explode('|', $line);
				if (count($parts) == 3) {
					$messages[] = array(
						'name' => $parts[0],
						'message' => $parts[1],
						'date_added' => $parts[2]
					);
				}
			}
			fclose($handle);

			// Update message with matching ID
			$found = false;
			foreach ($messages as $key => $message) {
				if ($key == $id) {
					$found = true;
					$messages[$id]['name'] = $name;
					$messages[$id]['message'] = $message;
					break;
				}
			}

			if ($found) {
				// Save messages to file
				$handle = fopen($filename, 'w');
				foreach ($messages as $message) {
					fwrite($handle, $message['name'] . '|' . $message['message'] . '|' . $message['date_added'] . "\n");
				}
				fclose($handle);
				echo "<p>Message updated successfully.</p>";
			} else {
				echo "<p>Message not found.</p>";
			}
		} else {
			echo "<p>No messages found.</p>";
		}
	}

	// Display messages
	echo "<table>
		<tr>
			<th>Name</th>
			<th>Message</th>
			<th>Date Added</th>
			<th>Actions</th>
		</tr>";
	$filename = 'messages.txt';
	if (file_exists($filename)) {
		$handle = fopen($filename, 'r');
		$messages = array();
		while (($line = fgets($handle)) !== false) {
			$parts = explode('|', $line);
			if (count($parts) == 3) {
				$messages[] = array(
					'name' => $parts[0],
					'message' => $parts[1],
					'date_added' => $parts[2]
				);
			}
		}
		fclose($handle);

		foreach ($messages as $key => $message) {
			echo "<tr>
				<td>{$message['name']}</td>
				<td>{$message['message']}</td>
				<td>" . date('Y-m-d H:i:s', $message['date_added']) . "</td>
				<td>
					<form method=\"post\">
						<input type=\"hidden\" name=\"action\" value=\"delete\">
						<input type=\"hidden\" name=\"id\" value=\"$key\">
						<label>Password:</label>
						<input type=\"password\" name=\"password\">
						<input type=\"submit\" value=\"Delete\">
					</form>
					<form method=\"post\">
						<input type=\"hidden\" name=\"action\" value=\"edit\">
						<input type=\"hidden\" name=\"id\" value=\"$key\">
						<label>Password:</label>
						<input type=\"password\" name=\"password\">
						<input type=\"submit\" value=\"Edit\">