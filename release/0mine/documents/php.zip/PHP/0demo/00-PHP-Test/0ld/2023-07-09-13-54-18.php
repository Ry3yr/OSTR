<!DOCTYPE html>
<html>
<head>
	<title>Issue Tracker</title>
	<style>
		input[type="submit"], input[type="button"] {
			display: none;
		}
	</style>
	<script>
		function checkInputs() {
			var boxes = document.querySelectorAll('input[type="text"]');
			var letters = '';
			for (var i = 0; i < boxes.length; i++) {
				letters += boxes[i].value.trim().toLowerCase();
			}
			if (letters === 'alashme') {
				document.querySelectorAll('input[type="submit"], input[type="button"]').forEach(function(button) {
					button.style.display = 'inline-block';
				});
			} else {
				document.querySelectorAll('input[type="submit"], input[type="button"]').forEach(function(button) {
					button.style.display = 'none';
				});
			}
		}
	</script>
</head>
<body>
	<h1>Issue Tracker</h1>

	<?php
	$password = 'f91'; // Change this to your desired password

	// Check if form has been submitted
	if (isset($_POST['submit'])) {
		// Get form data
		$title = $_POST['title'];
		$description = $_POST['description'];

		// Validate form data
		if (empty($title) || empty($description)) {
			echo "<p>Please fill out all fields.</p>";
		} else {
			// Save issue to file
			$filename = 'issues.txt';
			$handle = fopen($filename, 'a');
			fwrite($handle, $title . '|' . $description . '|' . time() . "\n");
			fclose($handle);

			echo "<p>Issue saved successfully.</p>";
		}
	}

	// Check if delete or edit form has been submitted
	if (isset($_POST['action']) && isset($_POST['id']) && $_POST['password'] === $password) {
		$action = $_POST['action'];
		$id = $_POST['id'];

		// Read issues from file
		$filename = 'issues.txt';
		if (file_exists($filename)) {
			$handle = fopen($filename, 'r');
			$issues = array();
			while (($line = fgets($handle)) !== false) {
				$parts = explode('|', $line);
				if (count($parts) == 3) {
					$issues[] = array(
						'title' => $parts[0],
						'description' => $parts[1],
						'date_added' => $parts[2]
					);
				}
			}
			fclose($handle);

			// Find issue with matching ID
			$found = false;
			foreach ($issues as $key => $issue) {
				if ($key == $id) {
					$found = true;
					break;
				}
			}

			if ($found) {
				// Perform requested action
				if ($action == 'delete') {
					unset($issues[$id]);
					// Re-index array keys
					$issues = array_values($issues);
					// Save issues to file
					$handle = fopen($filename, 'w');
					foreach ($issues as $issue) {
						fwrite($handle, $issue['title'] . '|' . $issue['description'] . '|' . $issue['date_added'] . "\n");
					}
					fclose($handle);
					echo "<p>Issue deleted successfully.</p>";
				} else if ($action == 'edit') {
					$title = $_POST['title'];
					$description = $_POST['description'];
					// Validate form data
					if (empty($title) || empty($description)) {
						echo "<p>Please fill out all fields.</p>";
					} else {
						// Update issue
						$issues[$id]['title'] = $title;
						$issues[$id]['description'] = $description;
						// Save issues to file
						$handle = fopen($filename, 'w');
						foreach ($issues as $issue) {
							fwrite($handle, $issue['title'] . '|' . $issue['description'] . '|' . $issue['date_added'] . "\n");
						}
						fclose($handle);
						echo "<p>Issue updated successfully.</p>";
					}
				}
			} else {
				echo "<p>Invalid issue ID.</p>";
			}
		}
	}
	?>
	
	<h2>Enter the letters:</h2>
	<input type="text" id="box1" onkeyup="checkInputs()" maxlength="1">
<input type="text" id="box2" onkeyup="checkInputs()" maxlength="1">
	<input type="text" id="box3" onkeyup="checkInputs()" maxlength="1">
	<input type="text" id="box4" onkeyup="checkInputs()" maxlength="1">
	<input type="text" id="box5" onkeyup="checkInputs()" maxlength="1">
	<input type="text" id="box6" onkeyup="checkInputs()" maxlength="1">

	<form method="post">
		<h2>Add Issue</h2>
		<label for="title">Title:</label>
		<input type="text" name="title" id="title">
		<label for="description">Description:</label>
		<textarea name="description" id="description"></textarea>
		<input type="submit" name="submit" value="Add Issue">
	</form>

	<h2>Current Issues</h2>
	<?php
	// Read issues from file
	$filename = 'issues.txt';
	if (file_exists($filename)) {
		$handle = fopen($filename, 'r');
		$issues = array();
		while (($line = fgets($handle)) !== false) {
			$parts = explode('|', $line);
			if (count($parts) == 3) {
				$issues[] = array(
					'title' => $parts[0],
					'description' => $parts[1],
					'date_added' => $parts[2]
				);
			}
		}
		fclose($handle);

		if (count($issues) > 0) {
			echo "<ul>";
			foreach ($issues as $key => $issue) {
				echo "<li>";
				echo "<h3>" . $issue['title'] . "</h3>";
				echo "<p>" . $issue['description'] . "</p>";
				echo "<p><em>Date added: " . date('Y-m-d H:i:s', $issue['date_added']) . "</em></p>";
				echo "<form method='post'>";
				echo "<input type='hidden' name='id' value='$key'>";
				echo "<input type='hidden' name='password' value='$password'>";
				echo "<input type='button' value='Edit' onclick='showEditForm($key)'>";
				echo "<input type='submit' name='action' value='delete' onclick='return confirm(\"Are you sure you want to delete this issue?\")'>";
				echo "</form>";
				echo "</li>";
			}
			echo "</ul>";
		} else {
			echo "<p>No issues found.</p>";
		}
	} else {
		echo "<p>No issues found.</p>";
	}
	?>

	<div id="editForm" style="display:none;">
		<form method="post">
			<h2>Edit Issue</h2>
			<label for="title">Title:</label>
			<input type="text" name="title" id="editTitle">
			<label for="description">Description:</label>
			<textarea name="description" id="editDescription"></textarea>
			<input type="hidden" name="id" id="editId">
			<input type="hidden" name="password" value="<?php echo $password ?>">
			<input type="submit" name="action" value="edit">
		</form>
	</div>

	<script>
		function showEditForm(id) {
			// Get issue data
			var title = document.querySelectorAll('h3')[id].textContent;
			var description = document.querySelectorAll('p')[id].textContent;
			// Populate form fields
			document.getElementById('editTitle').value = title;
			document.getElementById('editDescription').textContent = description;
			document.getElementById('editId').value = id;
			// Show form
			document.getElementById('editForm').style.display = 'block';
		}
	</script>
</body>
</html>