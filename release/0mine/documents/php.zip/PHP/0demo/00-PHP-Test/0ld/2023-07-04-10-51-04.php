$dir = 'C:\Konfi-Data\Export\json';
$files = scandir($dir);

$json_files = array();
foreach ($files as $file) {
    if (pathinfo($file, PATHINFO_EXTENSION) == 'json') {
        $json_files[] = $file;
    }
}

print_r($json_files);

<?php
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>
<a target="_blank" href="?source">Source Code</a>
</body>
</html>