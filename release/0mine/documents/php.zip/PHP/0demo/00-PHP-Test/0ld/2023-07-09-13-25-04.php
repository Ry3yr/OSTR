<form method="post">
	<label for="title">Title:</label>
	<input type="text" name="title" id="title" />

	<label for="description">Description:</label>
	<textarea name="description" id="description"></textarea>

	<label for="password">Password:</label>
	<input type="password" name="password" id="password" />

	<input type="submit" name="submit" value="Submit" />
</form>