<?php

// Step 1: Send a GET request to the Mastodon API
$url = 'https://mastodon.social/api/v1/accounts/lookup?acct=ryedai';
$response = file_get_contents($url);

// Step 2: Extract the URLs containing "headers" from the API response
$headers = json_decode($response, true)[0]['header_static'];
preg_match_all('/https:\/\/files\.mastodon\.social\/accounts\/headers\/\S+/', $headers, $matches);
$headerUrls = array_filter($matches[0], function($url) {
    return strpos($url, 'headers') !== false;
});

// Step 3: Display the header images using DOM
foreach ($headerUrls as $url) {
    echo '<img src="' . $url . '">';
}

?>