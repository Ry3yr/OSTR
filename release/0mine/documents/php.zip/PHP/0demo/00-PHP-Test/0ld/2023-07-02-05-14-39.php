<?php
$repoUrl = "https://api.github.com/repos/Ry3yr/OSTR/branches/main";
$opts = [
    "http" => [
        "method" => "GET",
        "header" => "Accept: application/vnd.github.v3+json"
    ]
];
$response = file_get_contents($repoUrl, false, stream_context_create($opts));
$data = json_decode($response, true);
$lastCommitTime = $data["commit"]["commit"]["author"]["date"];
// Display the last commit time
echo "Last commit time: " . $lastCommitTime;
?>


<?php
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>
<a target="_blank" href="?source">Source Code</a>
</body>
</html>