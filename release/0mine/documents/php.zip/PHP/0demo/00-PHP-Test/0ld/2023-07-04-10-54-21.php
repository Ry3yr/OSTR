<!DOCTYPE html>
<html>
<head>
    <title>JSON File List</title>
</head>
<body>
    <div>
        <form method="get">
            <label for="folder-path">Folder Path:</label>
            <input id="folder-path" name="folder" type="text" value="C:\Konfi-Data\Export\json">
            <button type="submit" name="submit">Load JSON Files</button>
        </form>
    </div>
    <?php
    if (isset($_GET['submit'])) {
        $folder = $_GET['folder'];
        $files = scandir($folder);

        if ($files === false) {
            echo '<div>Error: Invalid folder path</div>';
        } else {
            $json_files = array();
            foreach ($files as $file) {
                if (pathinfo($file, PATHINFO_EXTENSION) == 'json') {
                    $json_files[] = $file;
                }
            }

            if (empty($json_files)) {
                echo '<div>No JSON files found in the folder</div>';
            } else {
                echo '<div>';
                foreach ($json_files as $file) {
                    echo '<a href="' . $folder . '/' . $file . '">' . $file . '</a><br>';
                }
                echo '</div>';
            }
        }
    }
    ?>
</body>
</html>