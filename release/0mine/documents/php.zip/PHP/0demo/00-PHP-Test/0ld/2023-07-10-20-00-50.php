<?php
$url = 'https://rsshub.app/pixiv/user/75406576';

// Initialize curl
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// Get the RSS feed as a string
$xml_string = curl_exec($ch);

// Close the curl connection
curl_close($ch);

// Parse the XML data with DOMDocument and DOMXPath
$doc = new DOMDocument();
$doc->loadXML($xml_string);

$xpath = new DOMXPath($doc);
$xpath->registerNamespace('media', 'http://search.yahoo.com/mrss/');

// Iterate through the items and extract the image links
$items = $xpath->query('//item');
foreach ($items as $item) {
    $description = $xpath->query('media:content/@url', $item)->item(0)->nodeValue;
    echo '<img src="' . htmlspecialchars($description) . '">';
}
?>