<!DOCTYPE html>
<html>
<head>
	<title>Issue Tracker</title>
	<style>
		table {
			border-collapse: collapse;
			width: 100%;
		}
		th, td {
			text-align: left;
			padding: 8px;
			border-bottom: 1px solid #ddd;
		}
		th {
			background-color: #4CAF50;
			color: white;
		}
		form {
			margin-top: 20px;
		}
		label {
			display: block;
			margin-bottom: 8px;
		}
		input[type="text"], textarea {
			width: 100%;
			padding: 12px 20px;
			margin: 8px 0;
			box-sizing: border-box;
			border: 2px solid #ccc;
			border-radius: 4px;
			resize: vertical;
		}
		input[type="submit"] {
			background-color: #4CAF50;
			color: white;
			padding: 12px 20px;
			border: none;
			border-radius: 4px;
			cursor: pointer;
		}
		input[type="submit"]:hover {
			background-color: #45a049;
		}
		.error {
			color: red;
			margin-bottom: 10px;
		}
	</style>
</head>
<body>
	<h1>Issue Tracker</h1>

	<?php
	// Read disallowed phrases from file
	$disallow_file = 'disallow.txt';
	$disallowed_phrases = array();
	if (file_exists($disallow_file)) {
		$handle = fopen($disallow_file, 'r');
		while (($line = fgets($handle)) !== false) {
			$disallowed_phrases[] = trim($line);
		}
		fclose($handle);
	}

	// Check if form has been submitted
	if (isset($_POST['submit'])) {
		// Get form data
		$title = $_POST['title'];
		$description = $_POST['description'];

		// Check if submission contains disallowed phrases
		$contains_disallowed_phrase = false;
		foreach ($disallowed_phrases as $phrase) {
			if (stripos($title, $phrase) !== false || stripos($description, $phrase) !== false) {
				$contains_disallowed_phrase = true;
				break;
			}
		}

		if ($contains_disallowed_phrase) {
			echo "<p class='error'>Submission contains disallowed phrase. Please remove it and try again.</p>";
		} else {
			// Validate form data
			if (empty($title) || empty($description)) {
				echo "<p class='error'>Please fill out all fields.</p>";
			} else {
				// Save issue to file
				$filename = 'issues.txt';
				$handle = fopen($filename, 'a');
				fwrite($handle, $title . '|' . $description . '|' . time() . "\n");
				fclose($handle);

				echo "<p>Issue saved successfully.</p>";
			}
		}
	}

	// Read issues from file
	$filename = 'issues.txt';
	if (file_exists($filename)) {
		$handle = fopen($filename, 'r');
		$issues = array();
		while (($line = fgets($handle)) !== false) {
			$parts = explode('|', $line);
			if (count($parts) == 3) {
				$parts[1] = preg_replace(
					'@(https?://([-\w\.]+)+(:\d+)?(/([\w/_\.]*(\?\S+)?)?)?)@i',
					'<a href="$1" target="_blank">$1</a>',
					$parts[1]
				);
				$issues[] = array(
					'title' => $parts[0],
					'description' => $parts[1],
					'date_added' => $parts[2]
				);
			}
		}
		fclose($handle);

		// Sort issues by date added (most recent first)
		usort($issues, function($a, $b) {
			return $b['date_added'] - $a['date_added'];
		});

		// Display issues in a table
		echo '<h2>Issues</h2>';
		echo '<table>';
		echo '<tr><th>Title</th><th>Description</th><th>Date Added</th></tr>';
		foreach ($issues as $issue) {
			echo '<tr>';
			echo '<td>' . $issue['title'] . '</td>';
			echo '<td>' . $issue['description'] . '</td>';
		Here's the rest of the code with the CSS included: