<?php
// Set the Mastodon user to get the avatar for
$user = "ryedai";

// Set the URL for the RSS feed
$rss_url = "https://mastodon.social/@{$user}.rss";

// Load the RSS feed using SimpleXML
$rss = simplexml_load_file($rss_url);

// Find the first <url> tag in the RSS feed that contains an image URL with "avatars"
$image_url = null;
foreach ($rss->channel->item as $item) {
    $description = $item->description;
    $doc = new DOMDocument();
    @$doc->loadHTML($description);
    $xpath = new DOMXPath($doc);
    $img_src = $xpath->evaluate("string(//url[contains(text(), 'avatars')]/text())");
    if (!empty($img_src)) {
        $image_url = $img_src;
        break;
    }
}

// Extract the filename for the image from the URL
$filename = date("Y-m-d") . "-{$user}.jpg";

// Set the path to the directory to save the image
$dir = "./" . strtolower($user) . "/";

// Create the directory if it doesn't exist
if (!file_exists($dir)) {
    mkdir($dir);
}

// Download the image using cURL
$ch = curl_init($image_url);
$fp = fopen($dir . $filename, 'wb');
curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_exec($ch);
curl_close($ch);
fclose($fp);

// Append the image to an HTML file named after the user
$html_filename = "{$user}.html";
$html = "<html><body><img src=\"{$dir}{$filename}\"></body></html>";
file_put_contents($html_filename, $html, FILE_APPEND);

echo "Image downloaded and HTML file created successfully.";
?>