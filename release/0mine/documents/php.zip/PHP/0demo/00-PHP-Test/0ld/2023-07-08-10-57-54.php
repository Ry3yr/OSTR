<?php

// Step 1: Send a GET request to the Mastodon API
$url = 'https://mastodon.social/api/v1/accounts/lookup?acct=ryedai';
$response = file_get_contents($url);

// Step 2: Extract the headers' URLs from the API response
$headers = json_decode($response, true)[0]['header_static'];
preg_match_all('/https:\/\/files\.mastodon\.social\/accounts\/headers\/\S+/', $headers, $matches);
$headerUrls = $matches[0];

// Step 3: Display the header images using DOM
foreach ($headerUrls as $url) {
    echo '<img src="' . $url . '">';
}

?>