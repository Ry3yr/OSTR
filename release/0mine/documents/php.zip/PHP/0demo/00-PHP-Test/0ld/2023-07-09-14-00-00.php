<?php
$host = 'localhost';
$user = 'username';
$password = 'password';
$db_name = 'database_name';

$conn = mysqli_connect($host, $user, $password, $db_name);

if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Create a new board
    $board_name = $_POST['board_name'];
    $sql = "INSERT INTO boards (board_name) VALUES ('$board_name')";
    mysqli_query($conn, $sql);
    $board_id = mysqli_insert_id($conn);
    
    // Create a new list
    $list_name = $_POST['list_name'];
    $sql = "INSERT INTO lists (list_name, board_id) VALUES ('$list_name', $board_id)";
    mysqli_query($conn, $sql);
    $list_id = mysqli_insert_id($conn);
    
    // Create a new card
    $card_name = $_POST['card_name'];
    $card_description = $_POST['card_description'];
    $sql = "INSERT INTO cards (card_name, card_description, list_id) VALUES ('$card_name', '$card_description', $list_id)";
    mysqli_query($conn, $sql);
}
?>

<form action="" method="post">
    <input type="text" name="board_name" placeholder="Board name">
    <input type="text" name="list_name" placeholder="List name">
    <input type="text" name="card_name" placeholder="Card name">
    <textarea name="card_description" placeholder="Card description"></textarea>
    <input type="submit" value="Create card">
</form>