<!DOCTYPE html>
<html>
<head>
	<title>Issue Tracker</title>
	<style>
		.actions {
			display: none;
		}
	</style>
</head>
<body>
	<h1>Issue Tracker</h1>

	<?php
	$password = 'f91'; // Change this to your desired password

	// Check if form has been submitted
	if (isset($_POST['submit'])) {
		// Get form data
		$title = $_POST['title'];
		$description = $_POST['description'];

		// Validate form data
		if (empty($title) || empty($description)) {
			echo "<p>Please fill out all fields.</p>";
		} else {
			// Save issue to file
			$filename = 'issues.txt';
			$handle = fopen($filename, 'a');
			fwrite($handle, $title . '|' . $description . '|' . time() . "\n");
			fclose($handle);

			echo "<p>Issue saved successfully.</p>";
		}
	}

	// Check if delete or edit form has been submitted
	if (isset($_POST['action']) && isset($_POST['id']) && $_POST['password'] === $password) {
		$action = $_POST['action'];
		$id = $_POST['id'];

		// Read issues from file
		$filename = 'issues.txt';
		if (file_exists($filename)) {
			$handle = fopen($filename, 'r');
			$issues = array();
			while (($line = fgets($handle)) !== false) {
				$parts = explode('|', $line);
				if (count($parts) == 3) {
					$issues[] = array(
						'title' => $parts[0],
						'description' => $parts[1],
						'date_added' => $parts[2]
					);
				}
			}
			fclose($handle);

			// Find issue with matching ID
			$found = false;
			foreach ($issues as $key => $issue) {
				if ($key == $id) {
					$found = true;
					break;
				}
			}

			if ($found) {
				// Perform requested action
				if ($action == 'delete') {
					unset($issues[$id]);
					// Re-index array keys
					$issues = array_values($issues);
					// Save issues to file
					$handle = fopen($filename, 'w');
					foreach ($issues as $issue) {
						fwrite($handle, $issue['title'] . '|' . $issue['description'] . '|' . $issue['date_added'] . "\n");
					}
					fclose($handle);
					echo "<p>Issue deleted successfully.</p>";
				} else if ($action == 'edit') {
					$title = $_POST['title'];
					$description = $_POST['description'];
					// Validate form data
					if (empty($title) || empty($description)) {
						echo "<p>Please fill out all fields.</p>";
					} else {
						// Update issue
						$issues[$id]['title'] = $title;
						$issues[$id]['description'] = $description;
						// Save issues to file
						$handle = fopen($filename, 'w');
						foreach ($issues as $issue) {
							fwrite($handle, $issue['title'] . '|' . $issue['description'] . '|' . $issue['date_added'] . "\n");
						}
						fclose($handle);
						echo "<p>Issue updated successfully.</p>";
					}
				}
			} else {
				echo "<p>Invalid issue ID.</p>";
			}
		} else {
			echo "<p>No issues have been reported yet.</p>";
		}
	}

	// Display issues in a table
	echo '<h2>Issues</h2>';
	// Read issues from file
	$filename = 'issues.txt';
	if (file_exists($filename)) {
		$handle = fopen($filename, 'r');
		$issues = array();
		while (($line = fgets($handle)) !== false) {
			$parts = explode('|', $line);
			if (count($parts) == 3) {
				$issues[] = array(
					'title' => $parts[0],
					'description' => $parts[1],
					'date_added' => $parts[2]
				);
			}
		}
		fclose($handle);

		// Sort issues by date added (most recent first)
		usort($issues, function($a, $b) {
			return $b['date_added'] - $a['date_added'];
		});

		// Display issues in a table
		echo '<table>';
		echo '<thead><tr><th>Title</th><th>Description</th><th>Date Added</th><th>Actions</th></tr></thead>';
		echo '<tbody>';
		foreach ($issues as $key => $issue) {
			echo '<tr>';
			echo '<td>' . $issue['title'] . '</td>';
			echo '<td>' . $issue['description'] . '</td>';
			echo '<td>' . date('m/d/Y H:i:s', $issue['date_added']) . '</td>';
			echo '<td>';
			echo '<input type="checkbox" id="passwordCheckbox'.$key.'" name="passwordCheckbox" />';
			echo '<div class="actions">';
			echo '<form method="post" style="display:inline-block;margin-right:10px;">';
			echo '<input type="hidden" name="id" value="' . $key . '">';
			echo '<input type="hidden" name="action" value="edit">';
			echo '<label for="password">Password:</label>';
			echo '<input type="password" id="password" name="password" required>';
			echo '<br>';
			echo '<label for="title">Title:</label>';
			echo '<input type="text" id="title" name="title" value="' . $issue['title'] . '" required>';
			echo '<br>';
			echo '<label for="description">Description:</label>';
			echo '<textarea id="description" name="description" required>' . $issue['description'] . '</textarea>';
			echo '<br>';
			echo '<button type="submit">Save</button>';
			echo '</form>';
			echo '<form method="post" style="display:inline-block;">';
			echo '<input type="hidden" name="id" value="' . $key . '">';
			echo '<input type="hidden" name="action" value="delete">';
			echo '<label for="password">Password:</label>';
			echo '<input type="password" id="password" name="password" required>';
			echo '<br>';
			echo '<button type="submit">Delete</button>';
			echo '</form>';
			echo '</div>';
			echo '</td>';
			echo '</tr>';
		}
		echo '</tbody>';
		echo '</table>';
	} else {
		echo "<p>No issues have been reported yet.</p>";
	}
	?>

	<script>
		// Add event listener to the password checkbox
		var checkboxes = document.getElementsByName('passwordCheckbox');
		for (var i = 0; i < checkboxes.length; i++) {
			checkboxes[i].addEventListener('change', function() {
				var actionsDiv = this.parentNode.querySelector('.actions');
				if (this.checked) {
					actionsDiv.style.display = 'block';
				} else {
					actionsDiv.style.display = 'none';
				}
			});
		}
	</script>
</body>
</html>