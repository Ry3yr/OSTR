<php
$dir = 'C:\Konfi-Data\Export\json';
$files = scandir($dir);

$json_files = array();
foreach ($files as $file) {
    if (pathinfo($file, PATHINFO_EXTENSION) == 'json') {
        $json_files[] = $file;
    }
}

print_r($json_files);
?>