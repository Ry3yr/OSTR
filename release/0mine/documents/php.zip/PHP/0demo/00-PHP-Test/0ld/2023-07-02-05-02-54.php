<?php
if (isset($_POST['code'])) {
    // Get the code from the text area
    $code = $_POST['code'];

    // Get the current date and time
    $now = new DateTime();
    $date = $now->format('Y-m-d');
    $time = $now->format('H-i-s');

    // Create the new file name
    $filename = $date . '-' . $time . '.php';

    // Write the code to the new file
    file_put_contents($filename, $code);

    // Write the code to the "current" PHP file
    file_put_contents('current.php', $code);

    echo "Code saved to $filename and current.php";
}
?>

<form method="post">
    <textarea name="code"></textarea>
    <br>
    <input type="submit" value="Save">
</form>