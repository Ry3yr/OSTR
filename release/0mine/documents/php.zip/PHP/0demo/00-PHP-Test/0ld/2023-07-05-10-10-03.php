<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (isset($_FILES['files'])) {
		$uploadDir = 'uploads/';
		$uploadedFiles = array();

		foreach ($_FILES['files']['tmp_name'] as $key => $tmpName) {
			$fileName = $_FILES['files']['name'][$key];
			$fileSize = $_FILES['files']['size'][$key];
			$fileType = $_FILES['files']['type'][$key];
			$error = $_FILES['files']['error'][$key];

			if ($error == UPLOAD_ERR_OK) {
				$destination = $uploadDir . $fileName;
				if (move_uploaded_file($tmpName, $destination)) {
					$uploadedFiles[] = $fileName;
				} else {
					http_response_code(500);
					echo json_encode(array('status' => 'error', 'message' => 'Error uploading file: ' . $fileName));
					exit;
				}
			} else {
				http_response_code(500);
				echo json_encode(array('status' => 'error', 'message' => 'Error uploading file: ' . $fileName));
				exit;
			}
		}

		echo json_encode(array('status' => 'success', 'files' => $uploadedFiles));
		exit;
	} else {
		http_response_code(400);
		echo json_encode(array('status' => 'error', 'message' => 'No files uploaded'));
		exit;
	}
}