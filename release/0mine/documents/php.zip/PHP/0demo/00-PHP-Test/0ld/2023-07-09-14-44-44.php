<!DOCTYPE html>
<html>
<head>
	<title>Issue Tracker</title>
	<style>
		table {
			border-collapse: collapse;
			width: 100%;
		}
		th, td {
			text-align: left;
			padding: 8px;
			border-bottom: 1px solid #ddd;
		}
		th {
			background-color: #4CAF50;
			color: white;
		}
		form {
			margin-top: 20px;
		}
		label {
			display: block;
			margin-bottom: 8px;
		}
		input[type="text"], textarea {
			width: 100%;
			padding: 12px 20px;
			margin: 8px 0;
			box-sizing: border-box;
			border: 2px solid #ccc;
			border-radius: 4px;
			resize: vertical;
		}
		input[type="submit"] {
			background-color: #4CAF50;
			color: white;
			padding: 12px 20px;
			border: none;
			border-radius: 4px;
			cursor: pointer;
		}
		input[type="submit"]:hover {
			background-color: #45a049;
		}
		.char-counter {
			display: inline-block;
			margin-top: 8px;
			font-size: 12px;
			color: #888;
		}
		.char-counter.warning {
			color: red;
		}
	</style>
</head>
<body>
	<h1>Issue Tracker</h1>

	<?php
	// Check if form has been submitted
	if (isset($_POST['submit'])) {
	    // Get form data
	    $title = $_POST['title'];
	    $description = $_POST['description'];

	    // Validate form data
	    if (empty($title) || empty($description)) {
	        echo "<p>Please fill out all fields.</p>";
	    } else if (stripos($title, 'solved') !== false) {
	        echo "<p>Issue titles containing 'solved' are not allowed.</p>";
	    } else if (strlen($title) > 80) {
	        echo "<p>Title must be 80 characters or less.</p>";
	    } else {
	        // Parse URLs in description field and replace with clickable links
	        $description = preg_replace('/(https?:\/\/[\S]+)/', '<a href="$1" target="_blank">$1</a>', $description);
	    
	        // Save issue to file
	        $filename = 'issues.txt';
	        $handle = fopen($filename, 'a');
	        fwrite($handle, $title . '|' . $description . '|' . time() . "\n");
	        fclose($handle);
	    
	        echo "<p>Issue saved successfully.</p>";
	    }
	}
	
	// Read issues from file
	$filename = 'issues.txt';
	if (file_exists($filename)) {
	    $handle = fopen($filename, 'r');
	    $unsolved_issues = array();
	    $solved_issues = array();
	    while (($line = fgets($handle)) !== false) {
	        $parts = explode('|', $line);
	        if (count($parts) == 3) {
	            // Parse URLs in description field and replace with clickable links
	            $description = preg_replace('/(https?:\/\/[\S]+)/', '<a href="$1" target="_blank">$1</a>', $parts[1]);
	            
	            if (stripos($parts[0], 'solved') !== false) {
	                $solved_issues[] = array(
	                    'title' => $parts[0],
	                    'description' => $description,
	                    'date_added' => $parts[2]
	                );
	            } else {
	                $unsolved_issues[] = array(
	                    'title' => $parts[0],
	                    'description' => $description,
	                    'date_added' => $parts[2]
	                );
	            }
	        }
	    }
	    fclose($handle);
	    
	    // Sort issues by date added (most recent first)
	    usort($unsolved_issues, function($a, $b) {
	        return $b['date_added'] - $a['date_added'];
	    });
	    usort($solved_issues, function($a, $b) {
	        return $b['date_added'] - $a['date_added'];
	    });
	    
	    // Display unsolved issues in a table
	    echo '<h2>Unsolved Issues</h2>';
	    echo '<table>';
	    echo '<tr><th>Title</th><th>Description</th><th>Date Added</th></tr>';
	    foreach ($unsolved_issues as $issue) {
	        echo '<tr>';
	        echo '<td>' . $issue['title']. '</td>';
	        echo '<td>' . $issue['description'] . '</td>';
	        echo '<td>' . date('M j, Y g:i A', $issue['date_added']) . '</td>';
	        echo '</tr>';
	    }
	    echo '</table>';
	    
	    // Display solved issues in a table
	    echo '<h2>Solved Issues</h2>';
	    echo '<table>';
	    echo '<tr><th>Title</th><th>Description</th><th>Date Added</th></tr>';
	    foreach ($solved_issues as $issue) {
	        echo '<tr>';
	        echo '<td>' . $issue['title'] . '</td>';
	        echo '<td>' . $issue['description'] . '</td>';
	        echo '<td>' . date('M j, Y g:i A', $issue['date_added']) . '</td>';
	        echo '</tr>';
	    }
	    echo '</table>';
	} else {
	    echo "<p>No issues found.</p>";
	}
	?>
	
	<h2>Submit an Issue</h2>
	<form method="post" action="">
		<label for="title">Title:</label>
		<input type="text" id="title" name="title" maxlength="80" oninput="updateCharCount(this)">
		<div class="char-counter"><span class="current-count">0</span>/80</div>
		<label for="description">Description:</label>
		<textarea id="description" name="description"></textarea>
		<input type="submit" name="submit" value="Submit">
	</form>
	
	<script>
		function updateCharCount(element) {
			var currentCount = element.value.length;
			var maxCount = element.getAttribute("maxlength");
			var counter = element.nextElementSibling.querySelector(".current-count");
			counter.innerText = currentCount;
			if (currentCount > maxCount) {
				counter.classList.add("warning");
			} else {
				counter.classList.remove("warning");
			}
		}
	</script>
</body>
</html>