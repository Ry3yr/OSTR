<!DOCTYPE html>
<html>
<head>
	<title>Issue Tracker</title>
	<style>
		.spoiler {
			border: 1px solid #ccc;
			border-radius: 5px;
			padding: 10px;
			margin: 10px 0;
		}
		.spoiler label {
			font-weight: bold;
			cursor: pointer;
		}
		.spoiler input {
			display: none;
		}
		.spoiler input:checked ~ .spoiler-content {
			display: block;
		}
		.spoiler-content {
			display: none;
			margin-top: 10px;
		}
		table {
			border-collapse: collapse;
			width: 100%;
		}
		th, td {
			border: 1px solid #ccc;
			padding: 5px;
			text-align: left;
		}
		th {
			background-color: #eee;
		}
	</style>
</head>
<body>
	<h1>Issue Tracker</h1>

	<?php
	$password = 'f91'; // Change this to your desired password

	// Check if form has been submitted
	if (isset($_POST['submit'])) {
		// Get form data
		$title = $_POST['title'];
		$description = $_POST['description'];

		// Validate form data
		if (empty($title) || empty($description)) {
			echo "<p>Please fill out all fields.</p>";
		} else {
			// Save issue to file
			$filename = 'issues.txt';
			$handle = fopen($filename, 'a');
			fwrite($handle, $title . '|' . $description . '|' . time() . "\n");
			fclose($handle);

			echo "<p>Issue saved successfully.</p>";
		}
	}

	// Check if delete form has been submitted
	if (isset($_POST['action']) && isset($_POST['id']) && $_POST['password'] === $password && $_POST['action'] === 'delete') {
		$id = $_POST['id'];

		// Read issues from file
		$filename = 'issues.txt';
		if (file_exists($filename)) {
			$handle = fopen($filename, 'r');
			$issues = array();
			while (($line = fgets($handle)) !== false) {
				$parts = explode('|', $line);
				if (count($parts) == 3) {
					$issues[] = array(
						'title' => $parts[0],
						'description' => $parts[1],
						'date_added' => $parts[2]
					);
				}
			}
			fclose($handle);

			// Find issue with matching ID
			$found = false;
			foreach ($issues as $key => $issue) {
				if ($key == $id) {
					$found = true;
					break;
				}
			}

			if ($found) {
				// Perform requested action
				unset($issues[$id]);
				// Re-index array keys
				$issues = array_values($issues);
				// Save issues to file
				$handle = fopen($filename, 'w');
				foreach ($issues as $issue) {
					fwrite($handle, $issue['title'] . '|' . $issue['description'] . '|' . $issue['date_added'] . "\n");
				}
				fclose($handle);
				echo "<p>Issue deleted successfully.</p>";
			} else {
				echo "<p>Invalid issue ID.</p>";
			}
		} else {
			echo "<p>No issues have been reported yet.</p>";
		}
	}

	// Check if mark as solved form has been submitted
	if (isset($_POST['action']) && isset($_POST['id']) && $_POST['password'] === $password && $_POST['action'] === 'solved') {
		$id = $_POST['id'];

		// Read issues from file
		$filename = 'issues.txt';
		if (file_exists($filename)) {
			$handle = fopen($filename, 'r');
			$issues = array();
			while (($line = fgets($handle)) !== false) {
				$parts = explode('|', $line);
				if (count($parts) == 3) {
					$issue = array(
						'title' => $parts[0],
						'description' => $parts[1],
						'date_added' => $parts[2]
					);
					if ($id == count($issues)) {
						$issue['solved'] = true;
					}
					$issues[] = $issue;
				}
			}
			fclose($handle);

			// Save issues to file
			$handle = fopen($filename, 'w');
			foreach ($issues as $issue) {
				$solved_str = isset($issue['solved']) && $issue['solved'] ? 'solved' : '';
				fwrite($handle, $issue['title'] . '|' . $issue['description'] . '|' . $issue['date_added'] . '|' . $solved_str . "\n");
			}
			fclose($handle);

			echo "<p>Issue marked as solved successfully.</p>";
		} else {
			echo "<p>No issues have been reported yet.</p>";
		}
	}

	// Read issues from file
	$filename = 'issues.txt';
	if (file_exists($filename)) {
		$handle = fopen($filename, 'r');
		$issues = array();
		while (($line = fgets($handle)) !== false) {
			$parts = explode('|', $line);
			if (count($parts) >= 3) {
				$issue = array(
					'title' => $parts[0],
					'description' => $parts[1],
					'date_added' => $parts[2],
					'solved' => isset($parts[3]) && $parts[3] === 'solved'
				);
				$issues[] = $issue;
			}
		}
		fclose($handle);

		// Display issues
		echo "<table>";
		echo "<tr><th>Title</th><th>Description</th><th>Date Added</th><th>Action</th></tr>";
		foreach ($issues as $key => $issue) {
			$solved_str = $issue['solved'] ? ' (solved)' : '';
			echo "<tr><td>{$issue['title']}</td><td>{$issue['description']}</td><td>" . date('Y-m-d H:i:s', $issue['date_added']) . "</td><td>";
			echo "<form method='post' style='display: inline-block;'>";
			echo "<input type='hidden' name='action' value='delete'>";
			echo "<input type='hidden' name='id' value='$key'>";
			echo "<input type='password' name='password' placeholder='Password'>";
			echo "<button type='submit'>Delete</button>";
			echo "</form>";
			echo "<form method='post' style='display: inline-block;'>";
			echo "<input type='hidden' name='action' value='solved'>";
			echo "<input type='hidden' name='id' value='$key'>";
			echo "<input type='password' name='password' placeholder='Password'>";
			echo "<label><input type='checkbox' name='solved' onchange='this.form.submit();' ";
			if ($issue['solved']) {
				echo "checked='checked'";
			}
			echo "> Solved</label>";
			echo "</form>";
			echo "</td></tr>";
		}
		echo "</table>";
	} else {
		echo "<p>No issues have been reported yet.</p>";
	}
	?>

	<h2>Report an Issue</h2>
	<form method="post">
		<label for="title">Title:</label><br>
		<input type="text" id="title" name="title"><br>
		<label for="description">Description:</label><br>
		<textarea id="description" name="description"></textarea><br>
		<button type="submit" name="submit">Submit</button>
	</form>
</body>
</html>