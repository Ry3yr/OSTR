<?php
$host = 'localhost';
$user = 'username';
$password = 'password';
$db_name = 'database_name';

// Create connection
$conn = mysqli_connect($host, $user, $password);

// Check if connection succeeded
if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}

// Create database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS $db_name";
if (mysqli_query($conn, $sql)) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . mysqli_error($conn);
}

// Close connection
mysqli_close($conn);

// Reconnect to the database
$conn = mysqli_connect($host, $user, $password, $db_name);

// Check if connection succeeded
if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}
?>