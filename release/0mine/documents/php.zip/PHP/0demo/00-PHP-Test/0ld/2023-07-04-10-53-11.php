<!DOCTYPE html>
<html>
<head>
    <title>JSON File List</title>
</head>
<body>
    <div id="json-files"></div>

    <script>
        // Prompt the user for the folder path
        var folderPath = prompt('Enter the folder path:', '');

        // Use AJAX to call the PHP script and pass the folder path as a parameter
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    // Convert the list of JSON files to a JavaScript array
                    var jsonFiles = JSON.parse(xhr.responseText);

                    // Get the container element
                    var container = document.getElementById('json-files');

                    // Loop through the list of JSON files and create links for each one
                    for (var i = 0; i < jsonFiles.length; i++) {
                        var link = document.createElement('a');
                        link.href = folderPath + '/' + jsonFiles[i];
                        link.textContent = jsonFiles[i];
                        container.appendChild(link);
                        container.appendChild(document.createElement('br'));
                    }
                } else {
                    alert('Error: ' + xhr.status);
                }
            }
        };
        xhr.open('GET', 'get_json_files.php?folder=' + encodeURIComponent(folderPath));
        xhr.send();
    </script>
</body>
</html>