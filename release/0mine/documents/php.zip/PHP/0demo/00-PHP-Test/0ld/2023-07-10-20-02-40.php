<?php
$url = 'https://rsshub.app/pixiv/user/75406576';

// Initialize cURL
$ch = curl_init();
curl_setopt_array($ch, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => 1,
));

// Get the RSS feed as a string
$xml_string = curl_exec($ch);

// Close the cURL connection
curl_close($ch);

// Parse the XML data with DOMDocument and DOMXPath
$doc = new DOMDocument();
$doc->loadXML($xml_string, LIBXML_PARSEHUGE);

$xpath = new DOMXPath($doc);
$xpath->registerNamespace('media', 'http://search.yahoo.com/mrss/');

// Iterate through the items and extract the image links
$items = $xpath->query('//item');
for ($i = 0; $i < $items->length; $i++) {
    $item = $items->item($i);
    $description = $xpath->query('media:content/@url', $item)->item(0)->nodeValue;
    echo '<img src="' . htmlspecialchars($description) . '">';
}
?>