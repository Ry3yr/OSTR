<!DOCTYPE html>
<html>
<head>
    <title>JSON File List</title>
</head>
<body>
    <div id="json-files"></div>

    <script>
        // Use PHP to generate the list of JSON files
        <?php
        $dir = 'C:\Konfi-Data\Export\json';
        $files = scandir($dir);

        $json_files = array();
        foreach ($files as $file) {
            if (pathinfo($file, PATHINFO_EXTENSION) == 'json') {
                $json_files[] = $file;
            }
        }

        // Convert the list of JSON files to a JavaScript array
        $json_files_js = json_encode($json_files);
        echo "var jsonFiles = $json_files_js;";
        ?>

        // Get the container element
        var container = document.getElementById('json-files');

        // Loop through the list of JSON files and create links for each one
        for (var i = 0; i < jsonFiles.length; i++) {
            var link = document.createElement('a');
            link.href = 'C:/Konfi-Data/Export/json/' + jsonFiles[i];
            link.textContent = jsonFiles[i];
            container.appendChild(link);
            container.appendChild(document.createElement('br'));
        }
    </script>
</body>
</html>

<?php
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>
<a target="_blank" href="?source">Source Code</a>
</body>
</html>