<?php
// Read disallowed phrases from file
$disallow_file = 'disallow.txt';
$disallowed_phrases = array();
if (file_exists($disallow_file)) {
	$handle = fopen($disallow_file, 'r');
	while (($line = fgets($handle)) !== false) {
		$disallowed_phrases[] = trim($line);
	}
	fclose($handle);
}

// Check if form has been submitted
if (isset($_POST['submit'])) {
	// Get form data
	$title = $_POST['title'];
	$description = $_POST['description'];

	// Check if submission contains disallowed phrases
	$contains_disallowed_phrase = false;
	foreach ($disallowed_phrases as $phrase) {
		if (stripos($title, $phrase) !== false || stripos($description, $phrase) !== false) {
			$contains_disallowed_phrase = true;
			break;
		}
	}

	if ($contains_disallowed_phrase) {
		echo "<p>Submission contains disallowed phrase. Please remove it and try again.</p>";
	} else {
		// Validate form data
		if (empty($title) || empty($description)) {
			echo "<p>Please fill out all fields.</p>";
		} else {
			// Save issue to file
			$filename = 'issues.txt';
			$handle = fopen($filename, 'a');
			fwrite($handle, $title . '|' . $description . '|' . time() . "\n");
			fclose($handle);

			echo "<p>Issue saved successfully.</p>";
		}
	}
}

// Read issues from file
$filename = 'issues.txt';
if (file_exists($filename)) {
	$handle = fopen($filename, 'r');
	$issues = array();
	while (($line = fgets($handle)) !== false) {
		$parts = explode('|', $line);
		if (count($parts) == 3) {
			$parts[1] = preg_replace(
				'@(https?://([-\w\.]+)+(:\d+)?(/([\w/_\.]*(\?\S+)?)?)?)@i',
				'<a href="$1" target="_blank">$1</a>',
				$parts[1]
			);
			$issues[] = array(
				'title' => $parts[0],
				'description' => $parts[1],
				'date_added' => $parts[2]
			);
		}
	}
	fclose($handle);

	// Sort issues by date added (most recent first)
	usort($issues, function($a, $b) {
		return $b['date_added'] - $a['date_added'];
	});

	// Display issues in a table
	echo '<h2>Issues</h2>';
	echo '<table>';
	echo '<tr><th>Title</th><th>Description</th><th>Date Added</th></tr>';
	foreach ($issues as $issue) {
		echo '<tr>';
		echo '<td>' . $issue['title'] . '</td>';
		echo '<td>' . $issue['description'] . '</td>';
		echo '<td>' . date('Y-m-d H:i:s', $issue['date_added']) . '</td>';
		echo '</tr>';
	}
	echo '</table>';
} else {
	echo "<p>No issues have been reported yet.</p>";
}
?>

<form method="post">
	<label for="title">Title:</label>
	<input type="text" name="title" id="title" />

	<label for="description">Description:</label>
	<textarea name="description" id="description"></textarea>

	<input type="submit" name="submit" value="Submit" />
</form>