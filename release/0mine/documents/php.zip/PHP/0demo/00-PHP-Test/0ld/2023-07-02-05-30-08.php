<?php $allowSource=true;if(isset($_POST['code'])){$code=$_POST['code'];$now=new DateTime();$date=$now->format('Y-m-d');$time=$now->format('H-i-s');$filename=$date.'-'.$time.'.php';if($allowSource&&isset($_POST['allowSource'])){$sourceCodeLink="<?php\n"."    define(\"ALLOW_SOURCE\",TRUE);\n"."    define(\"ALLOW_TITLE\",TRUE);\n"."    if(ALLOW_SOURCE && isset(\$_GET['source'])){\n"."        highlight_file(__FILE__);\n"."        exit(0);\n"."    }\n"."?>\n"."<a target=\"_blank\" href=\"?source\">Source Code</a>\n"."</body>\n</html>";$code.="\n\n".$sourceCodeLink;}file_put_contents($filename,$code);file_put_contents('current.php',$code);echo"Code saved to $filename and current.php";}if(isset($_POST['move'])){$files=glob('*');if(!is_dir('0ld')){mkdir('0ld');}foreach($files as $file){if($file!='0test.php'&&$file!='current.php'){rename($file,'0ld/'.$file);}}echo "Files moved to 0ld directory";} ?>
<form method="post">
    <textarea name="code" cols="60" rows="15"></textarea>
    <br>
    <label>
        <input type="checkbox" name="allowSource">
        Add ALLOW SOURCE VIEW snippet
    </label>
    <br>
    <input type="submit" value="Save">
</form>
<?php if($allowSource&&isset($_POST['allowSource'])){echo "\n\n".$sourceCodeLink;} ?>
<form method="post">
    <input type="submit" name="move" value="Move Files">
</form>
<br>
<br><a target="_blank" href="current.php">CURRENT.PHP</a>