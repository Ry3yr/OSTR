<?php
// Set the API endpoint URL
$apiUrl = 'https://mastodon.social/api/v1/statuses/110678847371896994';

// Retrieve the JSON response from the API endpoint
$response = file_get_contents($apiUrl);

// Parse the JSON data into a PHP object
$data = json_decode($response);

// Display the status content and user avatar URL
echo '<div>' . $data->content . '</div>';
echo '<img src="' . $data->account->avatar . '">';
?>

<?php
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>
<a target="_blank" href="?source">Source Code</a>
</body>
</html>