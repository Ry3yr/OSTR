<!DOCTYPE html>
<html>
<head>
	<title>Issue Tracker</title>
	<style>
		.spoiler {
			border: 1px solid #ccc;
			border-radius: 5px;
			padding: 10px;
			margin: 10px 0;
		}
		.spoiler label {
			font-weight: bold;
			cursor: pointer;
		}
		.spoiler input {
			display: none;
		}
		.spoiler input:checked ~ .spoiler-content {
			display: block;
		}
		.spoiler-content {
			display: none;
			margin-top: 10px;
		}
		table {
			border-collapse: collapse;
			width: 100%;
		}
		th, td {
			border: 1px solid #ccc;
			padding: 5px;
			text-align: left;
		}
		th {
			background-color: #eee;
		}
	</style>
</head>
<body>
	<h1>Issue Tracker</h1>

	<?php
	if (isset($_POST['submit'])) {
		// Get form data
		$title = $_POST['title'];
		$description = $_POST['description'];

		// Validate form data
		if (empty($title) || empty($description)) {
			echo "<p>Please fill out all fields.</p>";
		} else {
			// Save issue to file
			$filename = 'issues.txt';
			$handle = fopen($filename, 'a');
			fwrite($handle, $title . '|' . $description . '|' . time() . "\n");
			fclose($handle);

			echo "<p>Issue saved successfully.</p>";
		}
	}

	// Check if delete form has been submitted
	if (isset($_POST['action']) && isset($_POST['id']) && $_POST['password'] === $password && $_POST['action'] === 'delete') {
		$id = $_POST['id'];

		// Read issues from file
		$filename = 'issues.txt';
		if (file_exists($filename)) {
			$handle = fopen($filename, 'r');
			$issues = array();
			while (($line = fgets($handle)) !== false) {
				$parts = explode('|', $line);
				if (count($parts) == 3) {
					$issues[] = array(
						'title' => $parts[0],
						'description' => $parts[1],
						'date_added' => $parts[2]
					);
				}
			}
			fclose($handle);

			// Find issue with matching ID
			$found = false;
			foreach ($issues as $key => $issue) {
				if ($key == $id) {
					$found = true;
					break;
				}
			}

			if ($found) {
				// Perform requested action
				unset($issues[$id]);
				// Re-index array keys
				$issues = array_values($issues);
				// Save issues to file
				$handle = fopen($filename, 'w');
				foreach ($issues as $issue) {
					fwrite($handle, $issue['title'] . '|' . $issue['description'] . '|' . $issue['date_added'] . "\n");
				}
				fclose($handle);
				echo "<p>Issue deleted successfully.</p>";
			} else {
				echo "<p>Invalid issue ID.</p>";
			}
		} else {
			echo "<p>No issues have been reported yet.</p>";
		}
	}

	// Display issues in a table
	$open_issues = array();
	$solved_issues = array();
	// Read issues from file
	$filename = 'issues.txt';
	if (file_exists($filename)) {
		$handle = fopen($filename, 'r');
		$issues = array();
		while (($line = fgets($handle)) !== false) {
			$parts = explode('|', $line);
			if (count($parts) == 3) {
				$issue = array(
					'title' => $parts[0],
					'description' => $parts[1],
					'date_added' => $parts[2]
				);
				if (strpos($issue['title'], '(solved)') !== false) {
					$solved_issues[] = $issue;
				} else {
					$open_issues[] = $issue;
				}
			}
		}
		fclose($andle);

		// Sort open issues by date added (most recent first)
		usort($open_issues, function($a, $b) {
			return $b['date_added'] - $a['date_added'];
		});

		// Display open issues in a table
		echo '<h2>Open Issues</h2>';
		if (!empty($open_issues)) {
			echo '<table>';
			echo '<tr><th>Title</th><th>Description</th><th>Date Added</th><th>Actions</th></tr>';
			foreach ($open_issues as $key => $issue) {
				echo '<tr>';
				echo '<td>' . $issue['title'] . '</td>';
				echo '<td>' . $issue['description'] . '</td>';
				echo '<td>' . date('Y-m-d H:i:s', $issue['date_added']) . '</td>';
				echo '<td>';
				echo '<form method="post">';
				echo '<input type="hidden" name="id" value="' . $key . '" />';
				echo '<input type="hidden" name="password" value="' . $password . '" />';
				echo '<input type="submit" name="action" value="delete" onclick="return confirm(\'Are you sure you want to delete this issue?\')" />';
				echo '</form>';
				echo '</td>';
				echo '</tr>';
			}
			echo '</table>';
		} else {
			echo "<p>No open issues have been reported yet.</p>";
		}

		// Sort solved issues by date added (most recent first)
		usort($solved_issues, function($a, $b) {
			return $b['date_added'] - $a['date_added'];
		});

		// Display solved issues in a spoiler tag
		echo '<div class="spoiler">';
		echo '<label>Show Solved Issues</label>';
		echo '<input type="checkbox" />';
		echo '<div class="spoiler-content">';
		if (!empty($solved_issues)) {
			echo '<table>';
			echo '<tr><th>Title</th><th>Description</th><th>Date Added</th></tr>';
			foreach ($solved_issues as $issue) {
				echo '<tr>';
				echo '<td>' . $issue['title'] . '</td>';
				echo '<td>' . $issue['description'] . '</td>';
				echo '<td>' . date('Y-m-d H:i:s', $issue['date_added']) . '</td>';
				echo '</tr>';
			}
			echo '</table>';
		} else {
			echo "<p>No solved issues have been reported yet.</p>";
		}
		echo '</div>';
		echo '</div>';
	} else {
		echo "<p>No issues have been reported yet.</p>";
	}
	?>

	<form method="post">
		<label for="title">Title:</label>
		<input type="text" name="title" id="title" />

		<label for="description">Description:</label>
		<textarea name="description" id="description"></textarea>

		<input type="submit" name="submit" value="Submit" />
	</form>
</body>
</html>