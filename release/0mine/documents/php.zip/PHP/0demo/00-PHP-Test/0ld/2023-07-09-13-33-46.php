<!DOCTYPE html>
<html>
<head>
    <title>Issue Tracker</title>
</head>
<body>
    <h1>Issue Tracker</h1>

    <?php
    // Check if form has been submitted
    if (isset($_POST['submit'])) {
        // Get form data
        $title = $_POST['title'];
        $description = $_POST['description'];

        // Validate form data
        if (empty($title) || empty($description)) {
            echo "<p>Please fill out all fields.</p>";
        } else {
            // Save issue to file
            $filename = 'issues.txt';
            $handle = fopen($filename, 'a');
            fwrite($handle, $title . '|' . $description . '|' . time() . "\n");
            fclose($handle);

            echo "<p>Issue saved successfully.</p>";
        }
    }

    // Read issues from file
    $filename = 'issues.txt';
    if (file_exists($filename)) {
        $handle = fopen($filename, 'r');
        $issues = array();
        while (($line = fgets($handle)) !== false) {
            $parts = explode('|', $line);
            if (count($parts) == 3) {
                $issues[] = array(
                    'title' => $parts[0],
                    'description' => $parts[1],
                    'date_added' => $parts[2]
                );
            }
        }
        fclose($handle);

        // Sort issues by date added (most recent first)
        usort($issues, function($a, $b) {
            return $b['date_added'] - $a['date_added'];
        });

        // Display issues in a table
        echo '<h2>Issues</h2>';
        echo '<table>';
        echo '<tr><th>Title</th><th>Description</th><th>Date Added</th><th>Edit</th><th>Delete</th></tr>';
        foreach ($issues as $issue) {
            echo '<tr>';
            echo '<td>' . $issue['title'] . '</td>';
            echo '<td>' . $issue['description'] . '</td>';
            echo '<td>' . date('Y-m-d H:i:s', $issue['date_added']) . '</td>';
            echo '<td><form method="post"><input type="hidden" name="id" value="' . $issue['date_added'] . '"><input type="submit" name="edit" value="Edit"></form></td>';
            echo '<td><form method="post"><input type="hidden" name="id" value="' . $issue['date_added'] . '"><input type="submit" name="delete" value="Delete"></form></td>';
            echo '</tr>';
        }
        echo '</table>';
    } else {
        echo "<p>No issues have been reported yet.</p>";
    }

    // Handle edit form submission
    if (isset($_POST['edit'])) {
        // Display edit form
        $id = $_POST['id'];
        $filename = 'issues.txt';
        $handle = fopen($filename, 'r');
        $issues = array();
        while (($line = fgets($handle)) !== false) {
            $parts = explode('|', $line);
            if (count($parts) == 3 && $parts[2] == $id) {
                $title = $parts[0];
                $description = $parts[1];
                break;
            }
        }
        fclose($handle);

        echo '<h2>Edit Issue</h2>';
        echo '<form method="post">';
        echo '<label for="title">Title:</label>';
        echo '<input type="text" name="title" id="title" value="' . $title . '" />';
        echo '<label for="description">Description:</label>';
        echo '<textarea name="description" id="description">' . $description . '</textarea>';
        echo '<input type="hidden" name="id" value="' . $id . '" />';
        echo '<input type="submit" name="edit_submit" value="Update" />';
        echo '</form>';
    }

    // Handle edit form submission
    if (isset($_POST['edit_submit'])) {
        // Get form data
        $id = $_POST['id'];
        $title = $_POST['title'];
        $description = $_POST['description'];

        // Validate form data
        if (empty($title) || empty($description)) {
            echo "<p>Please fill out all fields.</p>";
        } else {
            // Update issue in file
            $filename = 'issues.txt';
            $handle = fopen($filename, 'r');
            $issues = array();
            while (($line = fgets($handle)) !== false) {
                $parts = explode('|', $line);
                if (count($parts) == 3 && $parts[2] == $id) {
                    $issues[] = $title . '|' . $description . '|' . $id . "\n";
                } else {
                    $issues[] = $line;
                }
            }
            fclose($handle);

            $handle = fopen($filename, 'w');
            foreach ($issues as $issue) {
                fwrite($handle, $issue);
            }
            fclose($handle);

            echo "<p>Issue updated successfully.</p>";
        }
    }

    // Handle delete form submission
    if (isset($_POST['delete'])) {
        // Get form data
        $id = $_POST['id'];

        // Delete issue from file
        $filename = 'issues.txt';
        $handle = fopen($filename, 'r');
        $issues = array();
        while (($line = fgets($handle)) !== false) {
            $parts = explode('|', $line);
            if (count($parts) == 3 && $parts[2] != $id) {
                $issues[] = $line;
            }
        }
        fclose($handle);

        $handle = fopen($filename, 'w');
        foreach ($issues as $issue) {
            fwrite($handle, $issue);
        }
        fclose($handle);

        echo "<p>Issue deleted successfully.</p>";
    }
    ?>

    <h2>Report Issue</h2>
    <form method="post">
        <label for="title">Title:</label>
        <input type="text" name="title" id="title" />
        <label for="description">Description:</label>
        <textarea name="description" id="description"></textarea>
        <input type="submit" name="submit" value="Submit" />
    </form>
</body>
</html>