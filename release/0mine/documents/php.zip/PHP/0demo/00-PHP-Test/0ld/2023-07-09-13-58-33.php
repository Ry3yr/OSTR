<?php
$password = 'f91'; // Change this to your desired password

// Check if form has been submitted
if (isset($_POST['submit'])) {
    // Get form data
    $title = $_POST['title'];
    $description = $_POST['description'];

    // Validate form data
    if (empty($title) || empty($description)) {
        echo "<p>Please fill out all fields.</p>";
    } else {
        // Save issue to file
        $filename = 'issues.txt';
        $handle = fopen($filename, 'a');
        fwrite($handle, $title . '|' . $description . '|' . time() . "\n");
        fclose($handle);

        echo "<p>Issue saved successfully.</p>";
    }
}

// Check if delete or edit form has been submitted
if (isset($_POST['action']) && isset($_POST['id']) && $_POST['password'] === $password) {
    $action = $_POST['action'];
    $id = $_POST['id'];

    // Read issues from file
    $filename = 'issues.txt';
    if (file_exists($filename)) {
        $handle = fopen($filename, 'r');
        $issues = array();
        while (($line = fgets($handle)) !== false) {
            $parts = explode('|', $line);
            if (count($parts) == 3) {
                $issues[] = array(
                    'title' => $parts[0],
                    'description' => $parts[1],
                    'date_added' => $parts[2]
                );
            }
        }
        fclose($handle);

        // Find issue with matching ID
        $found = false;
        foreach ($issues as $key => $issue) {
            if ($key == $id) {
                $found = true;
                break;
            }
        }

        if ($found) {
            // Perform requested action
            if ($action == 'delete') {
                unset($issues[$id]);
                // Re-index array keys
                $issues = array_values($issues);
                // Save issues to file
                $handle = fopen($filename, 'w');
                foreach ($issues as $issue) {
                    fwrite($handle, $issue['title'] . '|' . $issue['description'] . '|' . $issue['date_added'] . "\n");
                }
                fclose($handle);
                echo "<p>Issue deleted successfully.</p>";
            } else if ($action == 'edit') {
                // Display edit form with current values
                echo '<h2>Edit Issue</h2>';
                echo '<form method="post">';
                echo '<label for="title">Title:</label>';
                echo '<input type="text" name="title" id="title" value="' . $issues[$id]['title'] . '" />';
                echo '<label for="description">Description:</label>';
                echo '<textarea name="description" id="description">' . $issues[$id]['description'] . '</textarea>';
                echo '<input type="hidden" name="id" value="' . $id . '" />';
                echo '<input type="hidden" name="password" value="' . $password . '" />';
                echo '<input type="submit" name="action" value="save" />';
                echo '</form>';
            } else if ($action == 'save') {
                $title = $_POST['title'];
                $description = $_POST['description'];
                // Validate form data
                if (empty($title) || empty($description)) {
                    echo "<p>Please fill out all fields.</p>";
                } else {
                    // Update issue
                    $issues[$id]['title'] = $title;
                    $issues[$id]['description'] = $description;
                    // Save issues to file
                    $handle = fopen($filename, 'w');
                    foreach ($issues as $issue) {
                        fwrite($handle, $issue['title'] . '|' . $issue['description'] . '|' . $issue['date_added'] . "\n");
                    }
                    fclose($handle);
                    echo "<p>Issue updated successfully.</p>";
                }
            }
        } else {
            echo "<p>Invalid issue ID.</p>";
        }
    } else {
        echo "<p>No issues have been reported yet.</p>";
    }
}

// Display issues in a table
echo '<h2>Issues</h2>';
// Read issues from file
$filename = 'issues.txt';
if (file_exists($filename)) {
    $handle = fopen($filename, 'r');
    $issues = array();
    while (($line