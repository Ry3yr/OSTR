<!DOCTYPE html>
<html>
<head>
	<title>Issue Tracker</title>
</head>
<body>
	<h1>Issue Tracker</h1>

	<?php
	// Check if form has been submitted
	if (isset($_POST['submit'])) {
		// Get form data
		$title = $_POST['title'];
		$description = $_POST['description'];

		// Validate form data
		if (empty($title) || empty($description)) {
			echo "<p>Please fill out all fields.</p>";
		} else {
			// Save issue to file
			$filename = 'issues.txt';
			$handle = fopen($filename, 'a');
			fwrite($handle, $title . '|' . $description . "\n");
			fclose($handle);

			echo "<p>Issue saved successfully.</p>";
		}
	}
	?>

	<form method="post">
		<label for="title">Title:</label>
		<input type="text" name="title" id="title" />

		<label for="description">Description:</label>
		<textarea name="description" id="description"></textarea>

		<input type="submit" name="submit" value="Submit" />
	</form>
</body>
</html>