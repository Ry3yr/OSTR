<!DOCTYPE html>
<html>
<head>
    <title>Upload YDK Files</title>
    <style>
        .button-container {
            display: inline-block;
            width: 150px;
            height: 150px;
            margin-right: 10px;
        }

        .button-text {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            width: 100%;
            height: 100%;
        }

        #buttons-container {
            white-space: nowrap;
            overflow-x: auto;
            width: 100%;
        }
    </style>
</head>
<body>
    <form action="" method="POST" enctype="multipart/form-data">
        <input type="file" name="file" />
        <input type="submit" name="submit" value="Upload" />
    </form>

    <div id="buttons-container">
        <?php
        $targetDir = 'ydk/'; // Folder to store the uploaded files

        if ($_FILES['file']['name']) {
            $targetFile = $targetDir . basename($_FILES['file']['name']);

            // Move the uploaded file to the target directory
            if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFile)) {
                echo 'File uploaded successfully.';
            } else {
                echo 'Error uploading file.';
            }
        }

        $folderPath = 'ydk/';
        $ydks = glob($folderPath . '*.ydk');

        // Get 3 random .ydk files
        $randomYdks = array_rand($ydks, 3);

        foreach ($randomYdks as $index) {
            $filename = basename($ydks[$index]);
            $shortFilename = str_pad($filename, 30, ' ');
            $filePath = $ydks[$index];

            // Read the specified line (line number 3) of the YDK file
            $targetLine = "";
            $file = fopen($filePath, "r");
            if ($file) {
                for ($i = 1; $i <= 3; $i++) {
                    $targetLine = fgets($file);
                    if ($i == 3) {
                        break;
                    }
                }
                fclose($file);
            }

            echo "<div class='button-container'><a href='$filePath' download><button class='button-text'>$shortFilename<br><br>$targetLine</button></a></div>";
        }
        ?>
    </div>
</body>
</html>