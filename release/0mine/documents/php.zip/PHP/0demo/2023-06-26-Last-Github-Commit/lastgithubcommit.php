<?php
$repoUrl = "https://api.github.com/repos/Ry3yr/OSTR/branches/main";
$opts = [
    "http" => [
        "method" => "GET",
        "header" => "Accept: application/vnd.github.v3+json"
    ]
];

// Make a GET request to the API endpoint for the repository's main branch
$response = file_get_contents($repoUrl, false, stream_context_create($opts));

// Parse the JSON data returned by the API
$data = json_decode($response, true);

// Get the last commit time of the main branch
$lastCommitTime = $data["commit"]["commit"]["author"]["date"];

// Display the last commit time
echo "Last commit time: " . $lastCommitTime;
?>
