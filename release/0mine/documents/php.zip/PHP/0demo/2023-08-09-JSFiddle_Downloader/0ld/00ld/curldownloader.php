<?php
$error = '';
$result = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $command = $_POST['command'];
    // Extract the URL from the cURL command
    preg_match("/'(.+?)'/", $command, $urlMatches);
    $url = $urlMatches[1];
    // Extract the Referer from the cURL command
    preg_match("/'Referer: (.+?)'/", $command, $refererMatches);
    $referer = $refererMatches[1];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_REFERER, $referer);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $output = curl_exec($ch);
    if ($output !== false) {
        $filename = 'fiddle.html';
        file_put_contents($filename, $output);
        $result = "File downloaded successfully as $filename.";
    } else {
        $error = "Error downloading file.";
    }
    curl_close($ch);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>cURL Command Executor</title>
</head>
<body>
    <form method="POST" action="">
        <label for="command">cURL Command:</label>
        <input type="text" name="command" id="command" required><br><br>
        <input type="submit" value="Execute">
    </form>
    <?php if ($error !== ''): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <?php if ($result !== ''): ?>
        <p style="color: green;"><?php echo $result; ?></p>
    <?php endif; ?>
</body>
</html>
