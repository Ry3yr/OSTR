<?php
$url = 'https://fiddle.jshell.net/aoikurayami/745t8aeh/2//show/';
$referer = 'https://fiddle.jshell.net/aoikurayami/745t8aeh/2//';
$outputFile = 'fiddle.html';
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_REFERER, $referer);
$fileHandle = fopen($outputFile, 'w');
curl_setopt($curl, CURLOPT_FILE, $fileHandle);
curl_exec($curl);
fclose($fileHandle);
if (curl_errno($curl)) {
    echo 'cURL error: ' . curl_error($curl);
} else {
    echo 'Request completed successfully.';
}
curl_close($curl);
?>
