<!DOCTYPE html>
<html>
<head>
    <title>JSFiddle Downloader</title>
</head>
<body>
    <?php
    $error = '';
    $result = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['jsfiddle_url'])) {
            $jsfiddle_url = $_POST['jsfiddle_url'];

            if (!preg_match("~^(?:f|ht)tps?://~i", $jsfiddle_url)) {
                $jsfiddle_url = "https://" . $jsfiddle_url;
            }

            $reformed_url = str_replace('jsfiddle.net', 'fiddle.jshell.net', $jsfiddle_url);
            $reformed_url = str_replace('/show', '', $reformed_url);
            $curl_command = "curl '" . $reformed_url . "//show/' -H 'Referer: " . $jsfiddle_url . "//' --output 'fiddle.html'";
            echo "<pre>" . $curl_command . "</pre>";

            $output = shell_exec($curl_command);
            if ($output === null) {
                $error = 'Error downloading file.';
            } else {
                $result = 'File downloaded successfully.';
                echo '<a target="_blank" href="fiddle.html">Link</a>';
            }
        }
    }
    ?>

    <!-- Display the form -->
    <form method="post">
        <label for="jsfiddle_url">JSFiddle URL:</label>
        <input type="text" name="jsfiddle_url" value="https://jsfiddle.net/aoikurayami/745t8aeh/2">
        <input type="submit" value="Generate cURL cmd">
    </form>

    <!-- Display the cURL command form -->
    <form method="POST" action="">
        <label for="command">cURL Command:</label>
        <input type="text" name="command" id="command" required value="<?php echo htmlspecialchars($curl_command ?? ''); ?>"><br><br>
        <input type="submit" value="Download JSFiddle">
    </form>

    <?php if ($error !== ''): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    <?php if ($result !== ''): ?>
        <p style="color: green;"><?php echo $result; ?></p>
    <?php endif; ?>

    <?php if (file_exists('fiddle.html')): ?>
        <iframe src="fiddle.html?<?php echo time(); ?>" frameborder="0" width="100%" height="500"></iframe>
    <?php endif; ?>

    <!-- Source code link -->
    <a target="_blank" href="?source">Source Code</a>

    <?php
    // Allow or disallow source viewing
    define("ALLOW_SOURCE", TRUE);
    define("ALLOW_TITLE", TRUE);
    if (ALLOW_SOURCE && isset($_GET['source'])) {
        highlight_file(__FILE__);
        exit(0);
    }
    ?>
</body>
</html>