<?php
$folderPath = 'htmls';
$files = glob($folderPath . '/*.html');
$fileCount = count($files);
$gridColumns = 6;
$gridRows = ceil($fileCount / $gridColumns);
?>

<div id="preview-container-wrapper"></div>

<script>
  // Function to append the preview containers to the wrapper div
  function appendPreviewContainers() {
    var wrapper = document.getElementById('preview-container-wrapper');
    <?php
    for ($row = 0; $row < $gridRows; $row++) {
      echo 'var row' . $row . ' = document.createElement("div");';
      echo 'row' . $row . '.style.display = "flex";';

      for ($col = 0; $col < $gridColumns; $col++) {
        $index = $row * $gridColumns + $col;
        if ($index < $fileCount) {
          $file = $files[$index];
          $fileName = basename($file);
          $objectPreview = '<object data="' . $file . '" width="300" height="200" scrolling="no"></object>';

          echo 'var container' . $index . ' = document.createElement("div");';
          echo 'container' . $index . '.className = "preview-container";';
          echo 'container' . $index . '.style.flex = "1";';
          echo 'container' . $index . '.style.margin = "5px";';
          echo 'container' . $index . '.innerHTML = \'' . $objectPreview . '<br><a href="' . $file . '" target="_blank">' . $fileName . '</a>\';';

          echo 'row' . $row . '.appendChild(container' . $index . ');';
        }
      }

      echo 'wrapper.appendChild(row' . $row . ');';
    }
    ?>
  }

  // Function to stop further data fetching after a specified delay
  function stopDataFetching() {
    var xhr = new XMLHttpRequest();
    xhr.abort();
  }

  // Call the function to append the preview containers
  appendPreviewContainers();

  // Wait for 20 seconds and then stop further data fetching
  setTimeout(stopDataFetching, 10000);
</script>