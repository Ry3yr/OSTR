
<?php
$folderPath = 'htmls';
$files = glob($folderPath . '/*.html');
$fileCount = count($files);
$gridColumns = 6;
$gridRows = ceil($fileCount / $gridColumns);
for ($row = 0; $row < $gridRows; $row++) {
    echo '<div style="display: flex;">';
    for ($col = 0; $col < $gridColumns; $col++) {
        $index = $row * $gridColumns + $col;
        if ($index < $fileCount) {
            $file = $files[$index];
            $fileName = basename($file);
            $objectPreview = '<object data="' . $file . '" width="300" height="200" scrolling="no"></object>';
            echo '<div class="preview-container" style="flex: 1; margin: 5px;">';
            echo $objectPreview;
            echo '<br>';
            echo '<a href="' . $file . '" target="_blank">' . $fileName . '</a>';
            echo '</div>';
        }
    }
    echo '</div>';
}
?>