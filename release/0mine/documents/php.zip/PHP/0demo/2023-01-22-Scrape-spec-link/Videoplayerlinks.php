<?php
$dom = new DOMDocument;

@$dom->loadHTML($html);
$links = $dom->getElementsByTagName('a');
$url = 'https://ry3yr.github.io/OSTR/Unresoundtracker/ygovrains.html';
$html = file_get_contents($url);
$dom = new DOMDocument();
@$dom->loadHTML($html);
$xpath = new DOMXPath($dom);
$nodes = $xpath->query('//a[@class="link"]');

foreach ($nodes as $node){
    echo $link->nodeValue;
    echo $node-> getAttribute('href'), '<br>';
}
?>
