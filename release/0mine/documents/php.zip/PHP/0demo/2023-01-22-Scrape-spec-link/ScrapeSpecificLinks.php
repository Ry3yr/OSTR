<?php
$dom = new DOMDocument;

@$dom->loadHTML($html);
$links = $dom->getElementsByTagName('a');
$url = 'https://codeberg.org/alceawisteria/pages/src/branch/main/images/arthost';
$html = file_get_contents($url);
$dom = new DOMDocument();
@$dom->loadHTML($html);
$xpath = new DOMXPath($dom);
$nodes = $xpath->query('//a[@class="muted"]');

foreach ($nodes as $node){
    echo $link->nodeValue;
    echo $node-> getAttribute('href'), '<br>';
}
?>
