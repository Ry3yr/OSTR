<?php
$dom = new DOMDocument;

@$dom->loadHTML($html);
$links = $dom->getElementsByTagName('a');
$url = 'http://alceawisteria.byethost7.com/PHP/0demo/2023-01-22-Scrape-spec-link/arthost.html';
$html = file_get_contents($url);
$dom = new DOMDocument();
@$dom->loadHTML($html);
$xpath = new DOMXPath($dom);
$nodes = $xpath->query('//a[@class="btn next-page-btn"]');

foreach ($nodes as $node){
    echo $link->nodeValue;
    echo $node-> getAttribute('href'), '<br>';
}
?>
