    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 16px;
            line-height: 1.6;
            color: #333;
            margin: 0;
            padding: 0;
        }
        h1, h2 {
            margin-top: 0;
            margin-bottom: 20px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            text-align: left;
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: orange;
            color: white;
        }
        table.solved-issues th {
            background-color: green;
            color: white;
        }
        form {
            margin-top: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
        }
        input[type="text"], textarea {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
            resize: vertical;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>

<div class="pre-spoiler"><input name="Deutsch" type="button" onClick="if (this.parentNode.getElementsByTagName('div')[0].style.display != 'none') { this.parentNode.getElementsByTagName('div')[0].style.display = 'none'; this.value = 'Mstdn'; } else { this.parentNode.getElementsByTagName('div')[0].style.display = 'block'; this.value = 'Mstdn';}" value="Mstdn" style="background:transparent; border:none; color:transparent;"><div class="spoiler" style="display: none;" >
<form action="" method="POST">
    <input type="submit" name="move_issues" value="Move All Solved Issues to Resolved">
</form>
<?php
// Check if the move issues button is clicked
if (isset($_POST['move_issues'])) {
    $sourceFile = 'issues.txt';
    $destinationFile = 'resolved.txt';
    // Read all lines from the source file
    $lines = file($sourceFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    // Filter the lines to include only those containing the word "Solved" (case-insensitive)
    $resolvedLines = array_filter($lines, function ($line) {
        return stripos($line, 'solved') !== false;
    });
    // Append the resolved lines to the destination file
    file_put_contents($destinationFile, implode("\n", $resolvedLines), FILE_APPEND);
    // Remove the resolved lines from the source file
    $remainingLines = array_diff($lines, $resolvedLines);
    file_put_contents($sourceFile, implode("\n", $remainingLines));
    // Redirect to the current page to refresh the issue list
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit();
}
?>
<a target="_blank" href="resolved.txt">OldRequests</a><br>
</div>


<!DOCTYPE html>
<html>
<head>
    <title>Request Tracker</title>
</head>
<body>
    <h1>Request Tracker</h1>
    <?php
    // Check if form has been submitted
    if (isset($_POST['submit'])) {
        // Get form data
        $title = $_POST['title'];
        $description = $_POST['description'];

        // Handle image upload
        $image = $_FILES['image'];
        $imageName = '';
        if ($image['error'] === UPLOAD_ERR_OK) {
            $imageName = time() . '_' . $image['name'];
            $imagePath = 'images/' . $imageName;
            move_uploaded_file($image['tmp_name'], $imagePath);
        }

        // Check if form data contains any disallowed words or phrases
        $disallow = file('disallow.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($disallow as $word) {
            if (stripos($title, $word) !== false || stripos($description, $word) !== false) {
                echo "<p style='color:red'>You are not allowed to use the word or phrase: " . htmlentities($word) . "</p>";
                break;
            }
        }
        // Validate form data
        if (empty($title) || empty($description)) {
            echo "<p>Please fill out all fields.</p>";
        } else {
            // Save issue to file
            $filename = 'issues.txt';
            $handle = fopen($filename, 'a');
            fwrite($handle, $title . '|' . $description . '|' . $imageName . '|' . time() . "\n");
            fclose($handle);
            echo "<p>RQ saved successfully.</p>";
        }
    }
    // Read issues from file
    $filename = 'issues.txt';
    if (file_exists($filename)) {
        $handle = fopen($filename, 'r');
        $issues = array();
        $solved_issues = array();
        while (($line = fgets($handle)) !== false) {
            $parts = explode('|', $line);
            if (count($parts) == 4) {
                $parts[1] = preg_replace(
                   '@(https?:\/\/[^\s/$.?#].[^\s]*)@i',
                    '<a href="$1" target="_blank">$1</a>',
                    $parts[1]
                );
                $issue = array(
                    'title' => $parts[0],
                    'description' => $parts[1],
                    'image' => $parts[2],
                    'date_added' => $parts[3]
                );
                // Render any • character as a line break
                $issue['description'] = str_replace('•', '<br>', $issue['description']);
                if (stripos($issue['title'], 'solved') !== false || stripos($issue['description'], 'solved') !== false) {
                    $solved_issues[] = $issue;
                } else {
                    $issues[] = $issue;
                }
            }
        }
        fclose($handle);
        // Sort issues by date added (most recent first)
        usort($issues, function($a, $b) {
            return $b['date_added'] - $a['date_added'];
        });
        // Display all issues in a table
        echo '<h2>All Issues</h2>';
        echo '<table>';
        echo '<tr><th>Title</th><th>Description</th><th>Image</th><th>Date Added</th></tr>';
        foreach ($issues as $issue) {
            echo '<tr>';
            echo '<td>' . $issue['title'] . '</td>';
            echo '<td>' . $issue['description'] . '</td>';
            echo '<td><a href="images/' . $issue['image'] . '" target="_blank"><img src="images/' . $issue['image'] . '" alt="Issue Image" width="50"></a></td>';
            echo '<td>' . date('Y-m-d H:i:s', $issue['date_added']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';
        // Display solved issues in a separate table
        if (!empty($solved_issues)) {
            echo '<h2>Solved Issues</h2>';
            echo '<table class="solved-issues">';
            echo '<tr><th>Title</th><th>Description</th><th>Image</th><th>Date Added</th></tr>';
            foreach ($solved_issues as $issue) {
    echo '<tr>';
    echo '<td>' . $issue['title'] . '</td>';
    echo '<td>' . $issue['description'] . '</td>';
    echo '<td><a href="images/' . $issue['image'] . '" target="_blank"><img src="images/' . $issue['image'] . '" alt="Issue Image" width="100"></a></td>';
    echo '<td>' . date('Y-m-d H:i:s', $issue['date_added']) . '</td>';
    echo '</tr>';
}
            echo '</table>';
        }
    } else {
        echo "<p>No issues found.</p>";
    }
    ?>
    <h2>Add New Request</h2>
    <form action="" method="POST" enctype="multipart/form-data">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required><br>

        <label for="description">Description:</label>
        <textarea id="description" name="description" required></textarea><br>

        <label for="image">Image:</label>
        <input type="file" id="image" name="image"><br>

        <input type="submit" name="submit" value="Submit">
    </form>
<script>
        // Listen for Enter key press in description textarea and append • character
        var descriptionTextarea = document.getElementById('description');
        descriptionTextarea.addEventListener('keydown', function(event) {
            if (event.keyCode === 13) {
                event.preventDefault();
                var selectionStart = descriptionTextarea.selectionStart;
                var selectionEnd = descriptionTextarea.selectionEnd;
                var text = descriptionTextarea.value;
                descriptionTextarea.value = text.substring(0, selectionStart) + '•' + text.substring(selectionEnd);
                descriptionTextarea.setSelectionRange(selectionStart + 1, selectionStart + 1);
            }
        });
    </script>
</body>
</html>
