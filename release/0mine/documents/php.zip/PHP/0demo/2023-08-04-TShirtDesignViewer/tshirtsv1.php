<?php
$folderPath = 'T-Shirts/';
$images = glob($folderPath . '*.{jpg,jpeg,png,gif}', GLOB_BRACE);

if (empty($images)) {
    echo 'No images found in the folder.';
} else {
    // Sort the images array in descending order based on file modification time
    usort($images, function($a, $b) {
        return filemtime($b) - filemtime($a);
    });

    // Display the images
    echo '<div style="display: flex; flex-wrap: wrap;">';
    foreach ($images as $image) {
        echo '<div style="width: 250px; height: 250px; margin: 10px;">';
        echo '<img src="' . $image . '" alt="T-Shirt Image" style="width: 100%; height: 100%; object-fit: cover;" />';
        echo '</div>';
    }
    echo '</div>';
}
?>