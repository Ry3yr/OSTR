<?php
$url = 'https://ry3yr.github.io/OSTR/Diarykeepers_Homepage/Cool_Stuff.html';
$html = file_get_contents($url);

$start = strpos($html, '<!------Tools---------->');
$end = strpos($html, '<!-----Hobbies---->', $start);

$length = $end - $start;
$result = substr($html, $start, $length);

echo $result;
?>