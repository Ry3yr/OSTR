
<?php
// define the url to scrape
$url = "http://alceawisteria.byethost7.com/PHP/0demo/";

// get the contents of the webpage
$html = file_get_contents($url);

// create an empty array to store the links
$links = array();

// create a DOM document object
$dom = new DOMDocument();

// load the HTML into the DOM object
@$dom->loadHTML($html);

// loop through each <a> tag in the DOM object
foreach($dom->getElementsByTagName('a') as $link) {
    // get the href attribute of the <a> tag
    $href = $link->getAttribute('href');

    // ignore links with C=D;O=A
    if (strpos($href, 'C=D;O=A') !== false) {
        continue;
    }

    // check if the link is already in the array
    if (!in_array($href, $links)) {
        // add the link to the array
        $links[] = $href;

        // make the link clickable and add a line break
        echo '<a href="' . $url . $href . '">' . $href . '</a><br>';
    }
}
?>