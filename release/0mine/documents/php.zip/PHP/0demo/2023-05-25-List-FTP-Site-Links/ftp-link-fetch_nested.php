<?php
function get_links($url) {
    $html = file_get_contents($url);
    $doc = new DOMDocument();
    @$doc->loadHTML($html);
    $links = array();
    foreach($doc->getElementsByTagName('a') as $link) {
        $href = $link->getAttribute('href');
        if (strpos($href, 'C=') === false && !in_array($href, $links)) {
            if (strpos($href, 'http') !== 0) {
                $href = $url . '/' . $href;
            }
            $links[] = $href;
            echo '<a href="' . $href . '">' . $href . '</a><br>';
            if (strpos($href, 'http') === 0) {
                get_links($href);
            }
        }
    }
}

get_links('http://alceawisteria.byethost7.com/PHP/0demo/');
?>