<a target="_blank" href="https://www.dekudeals.com/collection/nw7vnrstb9">Link</a>&nbsp;
<a target="_blank" href="http://alceawisteria.byethost7.com/PHP/0demo/2023-04-30-parse-json/parse.php#inks/more/67087617">reload</a>
<br>



<?php
//$json = file_get_contents('collection.json');
$json = file_get_contents('https://ry3yr.github.io/OSTR/Diarykeepers_Homepage/collection.json');
//Decode JSONV
$json_data = json_decode($json,true);

// Read sorting parameter from URL
$sort_by = isset($_GET['sort']) ? $_GET['sort'] : null;

// Sort data according to sorting parameter
if ($sort_by == 'price_asc') {
    usort($json_data['items'], function($a, $b) {
        return $a['price_paid'] - $b['price_paid'];
    });
} else if ($sort_by == 'price_desc') {
    usort($json_data['items'], function($a, $b) {
        return $b['price_paid'] - $a['price_paid'];
    });
} else if ($sort_by == 'format_asc') {
    usort($json_data['items'], function($a, $b) {
        return strcmp($a['format'], $b['format']);
    });
} else if ($sort_by == 'format_desc') {
    usort($json_data['items'], function($a, $b) {
        return strcmp($b['format'], $a['format']);
    });
}

$peopleCount = 0;
?>
    <table>
        <tr>
            <th>Link</th>
            <th>Format <a href="?sort=format_asc">^</a> / <a href="?sort=format_desc">v</a></th>
            <th>Price <a href="?sort=price_asc">^</a> / <a href="?sort=price_desc">v</a></th>
        </tr>
    <?php foreach($json_data['items'] as $key=>$value):
        $peopleCount++;
        ?>
        <tr>
            <td><?php
            echo "<a target=_blank href=";
            echo $value['link'];
            echo ">";
            echo $value['name'];
            echo "</a>";
            ?></td>
            <td><?php echo $value['format']; ?></td>
            <td><?php echo $value['price_paid']; ?></td>
        </tr>
    <?php endforeach; ?>
    </table>
<?php
echo "•Total Games Count: ". $peopleCount;

// Count physical games
$total = 0;
foreach ($json_data["items"] as $value) {
    if($value["format"]=="physical"){
        $total = $total+1;
    }
}
echo "•Physical Games: $total";
file_put_contents('dekugames.html', ob_get_contents());
?>

<br><br>
﻿<?php
    //Allow or disallow source viewing
    define("ALLOW_SOURCE",TRUE);
    define("ALLOW_TITLE",TRUE);
    if(ALLOW_SOURCE && isset($_GET['source'])){
        highlight_file(__FILE__);
        exit(0);
    }
?>
<a target="_blank" href="?source">Source Code</a>

