<?php
//$json = file_get_contents('collection.json');
$json = file_get_contents('https://ry3yr.github.io/OSTR/Diarykeepers_Homepage/collection.json');
//Decode JSON
$json_data = json_decode($json, true);

// Read sorting parameter from URL
$sort_by = isset($_GET['sort']) ? $_GET['sort'] : null;

// Sort data according to sorting parameter
if ($sort_by == 'price_asc') {
    usort($json_data['items'], function($a, $b) {
        return $a['price_paid'] - $b['price_paid'];
    });
} else if ($sort_by == 'price_desc') {
    usort($json_data['items'], function($a, $b) {
        return $b['price_paid'] - $a['price_paid'];
    });
} else if ($sort_by == 'format_asc') {
    usort($json_data['items'], function($a, $b) {
        return strcmp($a['format'], $b['format']);
    });
} else if ($sort_by == 'format_desc') {
    usort($json_data['items'], function($a, $b) {
        return strcmp($b['format'], $a['format']);
    });
} else if ($sort_by == 'date_asc') {
    usort($json_data['items'], function($a, $b) {
        return strtotime($a['added_at']) - strtotime($b['added_at']);
    });
} else if ($sort_by == 'date_desc') {
    usort($json_data['items'], function($a, $b) {
        return strtotime($b['added_at']) - strtotime($a['added_at']);
    });
}

$peopleCount = 0;
?>
    <table>
        <tr>
            <th>Link</th>
            <th>Format <a href="?sort=format_asc">^</a> / <a href="?sort=format_desc">v</a></th>
            <th>Price <a href="?sort=price_asc">^</a> / <a href="?sort=price_desc">v</a></th>
            <th>Date Added <a href="?sort=date_asc">^</a> / <a href="?sort=date_desc">v</a></th>
        </tr>
    <?php foreach ($json_data['items'] as $key => $value) :
        $peopleCount++;
        ?>
        <tr>
            <td><?php
                echo "<a target=_blank href=";
                echo $value['link'];
                echo ">";
                echo $value['name'];
                echo "</a>";
                echo isset($value['note']) && strpos($value['note'], 'DigitalAlso') !== false ? ' DigitalAlso' : '';
                ?></td>
            <td><?php echo $value['format']; ?></td>
            <td><?php echo $value['price_paid']; ?></td>
            <td><?php echo date('m/d/Y', strtotime($value['added_at'])); ?></td>
        </tr>
    <?php endforeach; ?>
    </table>
<?php
echo "•Total Games Count: " . $peopleCount;

// Count physical games
$total = 0;
foreach ($json_data["items"] as $value) {
    if ($value["format"] == "physical") {
        $total = $total + 1;
    }
}
echo "•Physical Games: $total";
file_put_contents('dekugames.html', ob_get_contents());
?>

<br><br>
﻿<?php
//Allow or disallow source viewing
define("ALLOW_SOURCE", TRUE);
define("ALLOW_TITLE", TRUE);
if (ALLOW_SOURCE && isset($_GET['source'])) {
    highlight_file(__FILE__);
    exit(0);
}
?>