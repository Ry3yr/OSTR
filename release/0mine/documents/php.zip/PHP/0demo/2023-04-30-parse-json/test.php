<?php
$json = file_get_contents('collection.json');
//Decode JSONV
$json_data = json_decode($json,true);
$peopleCount = 0;
?>
    <table>
        <tr>
            <th>Link</th>
            <th>Format  avail.</th>
            <th>Price</th>
        </tr>
    <?php foreach($json_data['items'] as $key=>$value):
        $peopleCount++;
        ?>
        <tr>
            <td><?php echo $value['link']; ?></td>
            <td><?php echo $value['format']; ?></td>
            <td><?php echo $value['price_paid']; ?></td>
        </tr>
    <?php endforeach; ?>
    </table>
<?php
echo "Total Games Count: ". $peopleCount;