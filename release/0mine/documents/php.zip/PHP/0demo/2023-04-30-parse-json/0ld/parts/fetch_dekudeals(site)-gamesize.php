<?php
// Fetch the content of the URL
$url = 'https://www.dekudeals.com/items/astroneer';
$html = file_get_contents($url);

// Create a DOMDocument object and load the HTML content
$dom = new DOMDocument();
@$dom->loadHTML($html);

// Create a DOMXPath object to query the HTML
$xpath = new DOMXPath($dom);

// Find the download size element using XPath
$query = "//strong[contains(text(), 'Download size:')]/following-sibling::text()";
$downloadSize = $xpath->query($query)->item(0)->nodeValue;

// Output the extracted value
echo $downloadSize;
?>