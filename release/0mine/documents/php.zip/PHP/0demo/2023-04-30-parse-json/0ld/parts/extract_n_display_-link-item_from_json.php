<?php
// Fetch the JSON data from the URL
$jsonData = file_get_contents('https://ry3yr.github.io/OSTR/Diarykeepers_Homepage/collection.json');

// Decode the JSON data into an associative array
$data = json_decode($jsonData, true);

// Check if the JSON decoding was successful
if ($data !== null) {
    // Iterate over each item in the collection
    foreach ($data['items'] as $item) {
        // Check if the item has a "link" key
        if (isset($item['link'])) {
            // Display the value of the "link" key
            echo $item['link'] . "<br>";
        }
    }
} else {
    // JSON decoding failed
    echo "Failed to decode JSON data.";
}
?>