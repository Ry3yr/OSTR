
<base href="https://www.dekudeals.com">

<?php
include_once('simple_html_dom.php');

// Load the HTML from the URL
$html = file_get_html('https://www.dekudeals.com/collection/nw7vnrstb9');

// Find all the div elements with class 'h6 name'
$names = $html->find('div.h6.name');

// Find all the a elements with class 'main-link'
$links = $html->find('a.main-link');

// Find all the small elements with class 'text-muted'
$prices = $html->find('small.text-muted');

// Create the table header
echo "<table><tr><th>Link</th><th>Price</th></tr>";

// Loop through each element and add it to the table
foreach ($names as $key => $name) {
    echo "<tr>";
    //echo "<td>" . $name->plaintext . "</td>";
    echo "<td><a href='" . $links[$key]->href . "' target='_blank'>" . $links[$key]->plaintext . "</a></td>";
    echo "<td>" . $prices[$key]->plaintext . "</td>";
    echo "</tr>";
}

// Close the table
echo "</table>";
?>
