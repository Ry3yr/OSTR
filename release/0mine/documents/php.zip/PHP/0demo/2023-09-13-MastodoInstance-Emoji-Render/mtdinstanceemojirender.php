<?php
if (isset($_POST['instance']) || isset($_GET['mtdinstance'])) {
    $instance = isset($_GET['mtdinstance']) ? $_GET['mtdinstance'] : $_POST['instance'];
    $endpoint = 'https://' . $instance . '/api/v1/custom_emojis';
    $response = file_get_contents($endpoint);
    $customEmojis = json_decode($response, true);

    foreach ($customEmojis as $customEmoji) {
        $shortcode = $customEmoji['shortcode'];
        $url = $customEmoji['url'];
        $emojiTag = '<img src="' . $url . '" alt="' . $shortcode . '" width="45px">';
        echo $emojiTag;
    }
}
?>
<form method="POST" action="">
    <input type="text" id="instance" name="instance" required value="pb.todon.de">
    <button type="submit">Fetch Emojis</button>
</form>
