<?php
/*
 * Shoutbox - Admin. - shout-admin.php (utf-8)
 *  https://werner-zenk.de
 */


// Passwort
$passwort = "0000";

session_start();

// Passwort überprüfen
if (isset($_POST["passwort"])) {
 if ($_POST["passwort"] == $passwort) {
  $_SESSION["user"] = true;
 }
}

// Abmelden
if (isset($_GET["logout"])) {
 session_destroy();
 header("Location: shout-admin.php");
}

// DB
$db = new PDO('sqlite:' . "db/shout.sqt");
$ausgabe = '';

// Löschen
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 if (isset($_POST["option"])) {
  $params = $_POST["option"];
  $placeholder = implode(',', array_fill(0, count($params), '?'));
  $delete = $db->prepare("DELETE FROM shout WHERE id IN (" . $placeholder . ")");
  if ($delete->execute($params)) {
   $ausgabe .= '<p>&#10004; Die Nachrichten wurden gelöscht.</p>';
  }
 }
}

// Formular ausgeben
if (isset($_SESSION["user"])) {
 $ausgabe .= '<form method="post">';
  $select = $db->query("SELECT id, name, nachricht FROM shout ORDER BY id DESC");
  $nachrichten = $select->fetchAll();
  foreach ($nachrichten as $nachricht) {
   $ausgabe .= '<input type="checkbox" name="option[]" value="' . $nachricht["id"] . '" id="lbl' . $nachricht["id"] . '"> ';
   $ausgabe .= '<label for="lbl' . $nachricht["id"] . '"><strong>' . $nachricht["name"] . ':</strong> ' . $nachricht["nachricht"] . '</label><br>';
  }
 $ausgabe .= '<br><input type="submit" value="Löschen" title="Ausgewählte Nachrichten löschen"> -
 <input type="button" onClick="window.location.href=\'shout-admin.php?logout\'" value="Abmelden" title="Admin. abmelden">
 </form>';
}
else {
 // Anmeldung
 $ausgabe .= '<form method="post">
<label>Passwort: <input type="password" name="passwort" required="required"></label>
<input type="submit" value="&raquo;">
</form>';
}
?>
<!DOCTYPE html>
<html lang="de">
 <head>
  <meta charset="UTF-8">
  <title>Shoutbox - Admin.</title>

  <style>
  body {
   font-family: Verdana, Arial, Sans-Serif;
   font-size: 0.95rem;
  }

  fieldset {
   width: 450px;
   margin: Auto;
  }

  legend {
   color: #008FD5;
   font-weight: Bold;
  }

  input[type=checkbox]:checked + label {
   color: #DF0000;
  }
  </style>

 </head>
<body>


<fieldset>
 <legend>Shoutbox - Admin.</legend>
<?=$ausgabe;?>
</fieldset>


</body>
</html>