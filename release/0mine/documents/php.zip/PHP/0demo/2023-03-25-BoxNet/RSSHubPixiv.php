<?php
// Load the RSS feed into SimpleXML
$rss = simplexml_load_file('https://rsshub.app/pixiv/user/75406576');

// Loop through the RSS items and extract the relevant links
$links = [];
foreach ($rss->channel->item as $item) {
    $guid = (string) $item->guid;
    $isPermaLink = (string) $item->guid['isPermaLink'];
    if ($isPermaLink === 'false') {
        $links[] = (string) $item->link;
    }
}

// Output the links as a list in the DOM
?>
<?php foreach ($links as $link): ?>
    <a href="<?= htmlspecialchars($link) ?>"><?= htmlspecialchars($link) ?></a><br>
<?php endforeach; ?>