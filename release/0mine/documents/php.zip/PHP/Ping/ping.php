<?php

function ping($host){
  if(exec('echo EXEC') == 'EXEC'){
    exec(sprintf('ping -c 1 -W 5 %s', escapeshellarg($host)), $res, $rval);
  } elseif( function_exists('fsocketopen') ){
    $port = 80;
    $timeout= 6;
    $fsock = fsockopen($host, $port, $errno, $errstr, $timeout);
    if ( ! $fsock ){
      $rval = 0;
    } else {
      $rval = 1;
    }
  }
  return $rval === 0;
}


/* check if the host is up $host can also be an ip address */
$host = 'www.google.com';
$up = ping($host);